# PPO Training and Policy Selection

CLCRS trains its tier policy offline. Online deployment uses
the validated and frozen policy only.

The reference training flow is:

1. Prepare continuous runtime-object trace segments.
2. Keep training and validation profiles disjoint.
3. Build the calibrated environment using the existing
   topology, state, resolver, and reward modules.
4. Train PPO for 1,000,000 environment steps per seed.
5. Repeat with five independent random seeds.
6. Evaluate checkpoints deterministically on independent
   validation profiles.
7. Retain checkpoints satisfying the capacity-feasibility
   requirement and select the highest validation return.
8. Select the final policy from the five validated candidates.

The configured policy uses an 11-dimensional state and three
GPU-relative actions: Local, Near, and Far. The Actor-Critic
network uses two 256-unit hidden layers with Tanh activation.

## Adapter boundary

`adapter_template.py` defines the interface between the
training loop and the existing `src/clcrs` modules.

Before training, create `training/clcrs_adapter.py` by mapping
the actual interfaces in `environment.py` and `policy.py`.
Do not assume function or class names without checking those
files.

The adapter must provide training profiles, independent
validation profiles, environment construction, policy
construction, and the frozen normalization parameters.

The environment must use the existing Tier Resolver and
reward implementation. It must account for object creation,
access, and release events. Validation must report
`capacity_feasible` and `infeasible_action` in its info field.

## Dependencies

File creation, syntax checks, trace tests, and configuration
checks do not require PyTorch.

PyTorch is needed only when the training command is invoked.

## Local artifacts

Generated checkpoints are written to `artifacts/`. They are
excluded from version control. This reference repository does
not distribute trained weights, private traces, or experimental
server data.

This training scaffold is not a claim of verified production
integration. The adapter must be connected and checked against
the target CLCRS modules before training.

## CLCRS adapter and profile preparation

The actual adapter is:

    training/clcrs_adapter.py

The training entry point loads profile manifests from:

    data/training/
    data/validation/

Before training, provide real profile manifests and their JSONL
traces according to docs/PROFILE_MANIFEST.md.

The normalization parameters are fitted only from training profiles.
Validation profiles are used for independent policy evaluation.

The adapter makes one placement decision per object creation event.
Access events update path pressure, and release events restore
capacity.

Run static integration checks first:

    bash scripts/check_reference.sh

Only after real profiles have been supplied and PyTorch is available
should training be started:

    bash scripts/train_reference.sh --device auto
