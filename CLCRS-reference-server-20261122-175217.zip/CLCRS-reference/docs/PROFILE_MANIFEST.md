# CLCRS Profile Manifest

## 1. Directory layout

Training profiles:

    data/training/*.json

Independent validation profiles:

    data/validation/*.json

Trace files:

    data/traces/*.jsonl

A manifest is a profile description. It is not itself a trace.

## 2. Required manifest fields

Each profile must contain:

- schema_version: 1
- profile_id: unique profile identifier
- split: train or validation
- trace_file: trace path, relative to repository root or absolute
- allocation_alignment_bytes: allocation alignment
- topology.gpu: CUDA index and GPU-affinity NUMA node
- topology.nodes: node ID, socket ID and total memory
- topology.distance_matrix: Linux NUMA distance matrix
- runtime.nodes: free, guard and in-flight capacity
- runtime.path_calibration: idle bandwidth for each GPU-NUMA path
- runtime.path_pressure_source
- calibration.pressure_samples

## 3. Runtime path-pressure source

Two explicit modes are supported.

### measured_access_bandwidth

Each access event must provide:

    observed_bandwidth_bytes_per_sec

This field should contain the measured GPU-NUMA path bandwidth
corresponding to that access observation.

### trace_derived_throughput

When measured bandwidth is unavailable, the adapter can estimate
throughput from transferred bytes and the elapsed time since the
previous access on the same GPU-NUMA path.

This is a trace-derived proxy, not a hardware-counter measurement.
It must not be reported as direct hardware telemetry.

Both modes use:

    pressure = clip(1 - observed_bandwidth / idle_bandwidth, 0, 1)

## 4. Pressure normalization

calibration.pressure_samples contains raw pressure samples in [0,1].

The adapter applies the configured transformation:

    transformed = pressure / (1 - pressure + epsilon_press)

The minimum and maximum are fitted exclusively from training
profiles. Validation profiles are not used to fit normalization.

## 5. Object lifecycle

A create event generates one placement decision.

An access event updates the path-pressure observation of the
NUMA node on which that object was placed.

A release event restores the object's allocated capacity.

The environment does not perform active page migration.

## 6. Trace events

Create:

    timestamp_ns
    event = create
    object_id
    gpu_id
    size_bytes
    priority

Access:

    timestamp_ns
    event = access
    object_id
    direction
    transferred_bytes
    observed_bandwidth_bytes_per_sec (optional)

Release:

    timestamp_ns
    event = release
    object_id

Priority encoding:

    0 = Low
    1 = Normal
    2 = High

Directions:

    H2D
    D2H
    MAPPED

## 7. Data integrity

Do not populate training or validation profiles with invented
hardware topology, capacity, or bandwidth measurements.

Do not put private raw traces into a public source release without
checking their disclosure permissions.
