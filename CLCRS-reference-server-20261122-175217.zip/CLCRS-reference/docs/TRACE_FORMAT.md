# Runtime Trace Format

The reference trace format is chronological JSONL. Each line
represents one runtime event.

Supported events:

- `create`: object creation, GPU ID, size, and allocation-time priority.
- `access`: H2D, D2H, or mapped-memory access and transferred bytes.
- `release`: object release.

Priority values are Low=0, Normal=1, and High=2.

The example in `examples/trace_sample.jsonl` is synthetic and
does not contain measurements from the experimental server.

The environment must process events in timestamp order. Future
accesses and releases must not be exposed to the current policy
decision. Object release restores the corresponding capacity,
while access events update the relevant GPU-NUMA path state.

Actual workload traces are not included in this repository.
Users should provide their own permitted traces.

## Optional observed path bandwidth

An access record may additionally include:

    observed_bandwidth_bytes_per_sec

When present, this value is used as the observed GPU-NUMA path
bandwidth for pressure calculation.

When absent, it is accepted only if the profile explicitly selects
trace_derived_throughput. That mode estimates throughput from
transferred bytes and the elapsed time between path observations.

The derived value is a trace-based estimate, not a direct hardware
counter measurement.
