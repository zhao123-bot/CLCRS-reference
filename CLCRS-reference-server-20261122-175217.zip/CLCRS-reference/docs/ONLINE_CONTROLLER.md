# CLCRS Online Controller

## Control flow

The reference controller implements:

1. Initial tier feasibility checking.
2. Native fallback if no tier is feasible.
3. Direct resolution when exactly one tier is feasible.
4. P99 control-budget admission when multiple tiers are feasible.
5. State construction and frozen-policy inference.
6. Deadline checks after state construction, inference,
   and physical-node resolution.
7. Resource-state revalidation.
8. In-flight capacity reservation.
9. NUMA policy execution through an injected executor.
10. Native fallback after execution failure.

## Latency admission

For a page-aligned request size S:

    control_p99(S) <= theta * native_reference_p99(S)

The default theta is 0.05.

Latency curves must be measured on the target platform.
The reference implementation uses conservative upper-size buckets.
Requests outside the calibrated range are not admitted.

The deadline is:

    deadline = event_gate_entry + theta * native_reference_p99(S)

PPO inference is synchronous. Deadline checks do not interrupt
an inference pass already in progress.

## Reservation lifecycle

A successful reservation remains in-flight after NUMA policy setup.

After physical-page materialization, the runtime must refresh
the target node's free capacity and call:

    controller.notify_materialized(token, observed_free_bytes)

If policy setup or materialization fails before completion:

    controller.cancel_reservation(token)

The same snapshot lock must be shared by the runtime's capacity
refresh and placement paths in a concurrent implementation.

## Runtime interfaces

NumaExecutor:

    apply_policy(address, size_bytes, node_id) -> bool

NativeRuntime:

    fallback(request, reason)

These are injected platform interfaces. This repository does not
claim that a complete GPU offloading runtime or production mbind
integration is included.

## Training boundary

The paper's PPO learning stage is offline.

The online controller uses a frozen policy and deterministic
forward inference only.

This build batch does not execute training, install PyTorch,
generate weights, or distribute trained checkpoints.

## Page management

CLCRS controls initial NUMA policy before first touch.

It does not actively migrate already materialized pages.
Linux remains responsible for physical-page materialization.
