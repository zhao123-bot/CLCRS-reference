from dataclasses import dataclass
from typing import Optional, Tuple

from .state import (
    PlacementRequest,
    RuntimeSnapshot,
    select_representative_node,
)
from .topology import ACTION_TO_TIER, TIER_ORDER, Tier, TierMap


@dataclass(frozen=True)
class Resolution:
    tier: Tier
    node_id: int
    effective_capacity_bytes: int
    post_allocation_headroom_bytes: int


class TierResolver:

    @staticmethod
    def action_to_tier(action):
        if isinstance(action, int):
            if action not in ACTION_TO_TIER:
                raise ValueError("Invalid tier action.")
            return ACTION_TO_TIER[action]

        return Tier(action)

    def feasible_tiers(
        self,
        snapshot: RuntimeSnapshot,
        tier_map: TierMap,
        request: PlacementRequest,
    ) -> Tuple[Tier, ...]:

        feasible = []

        for tier in TIER_ORDER:
            candidate = select_representative_node(
                snapshot,
                tier_map,
                tier,
                request.aligned_size_bytes,
            )

            if candidate is None:
                continue

            if (
                candidate.effective_capacity_bytes
                >= request.aligned_size_bytes
            ):
                feasible.append(tier)

        return tuple(feasible)

    def resolve(
        self,
        action,
        snapshot: RuntimeSnapshot,
        tier_map: TierMap,
        request: PlacementRequest,
    ) -> Optional[Resolution]:

        tier = self.action_to_tier(action)

        candidate = select_representative_node(
            snapshot,
            tier_map,
            tier,
            request.aligned_size_bytes,
        )

        if candidate is None:
            return None

        if (
            candidate.effective_capacity_bytes
            < request.aligned_size_bytes
        ):
            return None

        return Resolution(
            tier=tier,
            node_id=candidate.node_id,
            effective_capacity_bytes=(
                candidate.effective_capacity_bytes
            ),
            post_allocation_headroom_bytes=(
                candidate.post_allocation_headroom_bytes
            ),
        )

    def reserve_inflight(
        self,
        snapshot: RuntimeSnapshot,
        node_id: int,
        size_bytes: int,
    ) -> bool:

        state = snapshot.node_states.get(node_id)

        if state is None or not state.online or not state.allowed:
            return False

        if size_bytes <= 0:
            return False

        if state.effective_capacity_bytes < size_bytes:
            return False

        state.inflight_bytes += size_bytes
        snapshot.version += 1

        return True

    @staticmethod
    def release_inflight(
        snapshot: RuntimeSnapshot,
        node_id: int,
        size_bytes: int,
    ):

        state = snapshot.node_states[node_id]

        if size_bytes <= 0 or state.inflight_bytes < size_bytes:
            raise ValueError("Invalid in-flight reservation release.")

        state.inflight_bytes -= size_bytes
        snapshot.version += 1
