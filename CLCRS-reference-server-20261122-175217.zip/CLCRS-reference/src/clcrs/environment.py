from copy import deepcopy
from dataclasses import asdict, dataclass
from typing import Dict, Optional, Tuple

from .resolver import TierResolver
from .reward import RewardModel
from .state import (
    PlacementRequest,
    RuntimeSnapshot,
    SizeNormalizer,
    StateBuilder,
    compute_path_pressure,
)
from .topology import Tier, TierMap


@dataclass(frozen=True)
class EnvironmentStep:
    reward: float
    done: bool
    next_state: Optional[Tuple[float, ...]]
    info: Dict


class OfflinePlacementEnvironment:

    def __init__(
        self,
        initial_snapshot: RuntimeSnapshot,
        tier_map: TierMap,
        state_builder: StateBuilder,
        reward_model: RewardModel,
        resolver: Optional[TierResolver] = None,
    ):
        self.initial_snapshot = deepcopy(initial_snapshot)
        self.tier_map = tier_map
        self.state_builder = state_builder
        self.reward_model = reward_model
        self.resolver = resolver or TierResolver()

        self.snapshot = deepcopy(initial_snapshot)
        self.active_objects = {}

    def reset(self):
        self.snapshot = deepcopy(self.initial_snapshot)
        self.active_objects = {}
        return deepcopy(self.snapshot)

    def state_for(self, request: PlacementRequest):
        return self.state_builder.build(
            self.snapshot,
            self.tier_map,
            request,
        )

    def step(
        self,
        request: PlacementRequest,
        action,
        next_request: Optional[PlacementRequest] = None,
        episode_end: bool = False,
    ) -> EnvironmentStep:

        if request.object_id in self.active_objects:
            raise ValueError("Object is already active.")

        resolution = self.resolver.resolve(
            action,
            self.snapshot,
            self.tier_map,
            request,
        )

        if resolution is None:
            result = self.reward_model.infeasible()

            return EnvironmentStep(
                reward=result.reward,
                done=True,
                next_state=None,
                info={
                    "infeasible": True,
                    "action": str(action),
                    "reason": "No feasible physical node in selected tier.",
                },
            )

        result = self.reward_model.evaluate(
            self.snapshot,
            self.tier_map,
            request,
            resolution,
        )

        if result.infeasible:
            return EnvironmentStep(
                reward=result.reward,
                done=True,
                next_state=None,
                info={"infeasible": True},
            )

        node_state = self.snapshot.node_states[resolution.node_id]

        if node_state.free_bytes < request.aligned_size_bytes:
            raise RuntimeError("Insufficient physical free capacity.")

        node_state.free_bytes -= request.aligned_size_bytes

        self.active_objects[request.object_id] = (
            resolution.node_id,
            request.aligned_size_bytes,
        )

        self.snapshot.version += 1

        next_state = None

        if next_request is not None:
            next_state = self.state_for(next_request).values

        return EnvironmentStep(
            reward=result.reward,
            done=bool(episode_end),
            next_state=next_state,
            info={
                "infeasible": False,
                "tier": resolution.tier.value,
                "node_id": resolution.node_id,
                "reward_terms": asdict(result),
                "snapshot_version": self.snapshot.version,
            },
        )

    def release_object(self, object_id: str) -> bool:

        allocation = self.active_objects.pop(object_id, None)

        if allocation is None:
            return False

        node_id, size_bytes = allocation
        state = self.snapshot.node_states[node_id]

        state.free_bytes += size_bytes
        self.snapshot.version += 1

        return True

    def observe_path_bandwidth(
        self,
        gpu_index: int,
        node_id: int,
        observed_bandwidth: float,
        idle_bandwidth: float,
    ):

        if node_id not in self.tier_map.nodes:
            raise ValueError("Unknown NUMA node.")

        pressure = compute_path_pressure(
            observed_bandwidth,
            idle_bandwidth,
        )

        self.snapshot.path_pressure[(gpu_index, node_id)] = pressure
        self.snapshot.version += 1

        return pressure

    def snapshot_copy(self):
        return deepcopy(self.snapshot)
