import math
from dataclasses import dataclass
from typing import Optional

from .resolver import Resolution
from .state import PlacementRequest, RuntimeSnapshot, clip01
from .topology import TierMap


@dataclass(frozen=True)
class RewardConfig:
    base_reward: float = 1.0
    terminal_reward: float = -1.0

    alpha: float = 0.45
    beta: float = 0.25
    gamma_press: float = 0.30

    lambda_cap: float = 5.0
    epsilon_press: float = 0.05


@dataclass(frozen=True)
class RewardNormalization:
    pressure_lower: float
    pressure_upper: float


@dataclass(frozen=True)
class RewardBreakdown:
    reward: float
    capacity_penalty: Optional[float]
    static_path_penalty: Optional[float]
    runtime_pressure_penalty: Optional[float]
    capacity_margin: Optional[float]
    transformed_pressure: Optional[float]
    infeasible: bool = False


class RewardModel:

    def __init__(
        self,
        normalization: RewardNormalization,
        config: Optional[RewardConfig] = None,
    ):
        self.config = config or RewardConfig()
        self.normalization = normalization

        if self.config.lambda_cap <= 0:
            raise ValueError("lambda_cap must be positive.")

        if self.config.epsilon_press <= 0:
            raise ValueError("epsilon_press must be positive.")

        if (
            normalization.pressure_upper
            <= normalization.pressure_lower
        ):
            raise ValueError("Invalid pressure normalization range.")

    def infeasible(self):
        return RewardBreakdown(
            reward=self.config.terminal_reward,
            capacity_penalty=None,
            static_path_penalty=None,
            runtime_pressure_penalty=None,
            capacity_margin=None,
            transformed_pressure=None,
            infeasible=True,
        )

    def evaluate(
        self,
        snapshot: RuntimeSnapshot,
        tier_map: TierMap,
        request: PlacementRequest,
        resolution: Resolution,
    ) -> RewardBreakdown:

        node_id = resolution.node_id
        runtime = snapshot.node_states[node_id]
        topology = tier_map.nodes[node_id]

        effective = runtime.effective_capacity_bytes
        size = request.aligned_size_bytes

        if effective < size:
            return self.infeasible()

        usable = topology.total_memory_bytes - runtime.guard_bytes

        if usable <= 0:
            raise ValueError("Invalid usable node capacity.")

        margin = clip01((effective - size) / usable)

        lam = self.config.lambda_cap

        p_cap = (
            1.0 - math.exp(-lam * (1.0 - margin))
        ) / (
            1.0 - math.exp(-lam)
        )

        d_min, d_max = tier_map.distance_bounds

        if d_max == d_min:
            p_path = 0.0
        else:
            p_path = clip01(
                (tier_map.distance(node_id) - d_min)
                / (d_max - d_min)
            )

        key = (request.gpu_index, node_id)

        if key not in snapshot.path_pressure:
            raise KeyError("Missing runtime path pressure.")

        pressure = snapshot.path_pressure[key]

        if not 0.0 <= pressure <= 1.0:
            raise ValueError("Invalid path pressure.")

        transformed = pressure / (
            1.0 - pressure + self.config.epsilon_press
        )

        lower = self.normalization.pressure_lower
        upper = self.normalization.pressure_upper

        p_press = clip01(
            (transformed - lower) / (upper - lower)
        )

        reward = (
            self.config.base_reward
            - self.config.alpha * p_cap
            - self.config.beta * p_path
            - self.config.gamma_press * p_press
        )

        return RewardBreakdown(
            reward=reward,
            capacity_penalty=p_cap,
            static_path_penalty=p_path,
            runtime_pressure_penalty=p_press,
            capacity_margin=margin,
            transformed_pressure=transformed,
            infeasible=False,
        )
