from dataclasses import dataclass
from typing import Optional, Sequence
import math


@dataclass(frozen=True)
class LatencyBucket:
    max_size_bytes: int
    p99_ns: int

    def __post_init__(self):
        if self.max_size_bytes <= 0 or self.p99_ns <= 0:
            raise ValueError("Invalid latency bucket")


@dataclass(frozen=True)
class BudgetDecision:
    admitted: bool
    estimated_control_p99_ns: Optional[int]
    native_reference_p99_ns: Optional[int]
    budget_ns: int
    reason: str


class LatencyBudget:

    def __init__(
        self,
        control_buckets: Sequence[LatencyBucket],
        native_buckets: Sequence[LatencyBucket],
        theta: float = 0.05,
    ):
        self.theta = float(theta)

        if not math.isfinite(self.theta) or not 0 < self.theta <= 1:
            raise ValueError("Invalid latency budget ratio")

        self.control = self._validate(control_buckets)
        self.native = self._validate(native_buckets)

    @staticmethod
    def _validate(buckets):
        result = tuple(
            sorted(
                buckets,
                key=lambda x: x.max_size_bytes
            )
        )

        if not result:
            raise ValueError("Latency profile is empty")

        sizes = [x.max_size_bytes for x in result]

        if len(sizes) != len(set(sizes)):
            raise ValueError("Duplicate latency size bucket")

        return result

    @staticmethod
    def _lookup(buckets, size_bytes):
        for bucket in buckets:
            if size_bytes <= bucket.max_size_bytes:
                return bucket.p99_ns

        return None

    def evaluate(self, size_bytes: int) -> BudgetDecision:

        size_bytes = int(size_bytes)

        if size_bytes <= 0:
            raise ValueError("Invalid request size")

        control = self._lookup(self.control, size_bytes)
        native = self._lookup(self.native, size_bytes)

        if control is None or native is None:
            return BudgetDecision(
                admitted=False,
                estimated_control_p99_ns=control,
                native_reference_p99_ns=native,
                budget_ns=0,
                reason="missing_size_bucket",
            )

        budget = max(
            1,
            int(math.floor(native * self.theta))
        )

        admitted = control <= budget

        return BudgetDecision(
            admitted=admitted,
            estimated_control_p99_ns=control,
            native_reference_p99_ns=native,
            budget_ns=budget,
            reason=(
                "admitted"
                if admitted
                else "control_p99_exceeds_budget"
            ),
        )
