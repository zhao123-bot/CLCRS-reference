from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch.distributions import Categorical

from .state import FEATURE_ORDER
from .topology import TIER_ORDER, Tier


STATE_DIM = 11
ACTION_DIM = 3


class ActorCritic(nn.Module):

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
    ):
        super().__init__()

        self.actor = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.Tanh(),
            nn.Linear(256, 256),
            nn.Tanh(),
            nn.Linear(256, action_dim),
        )

        self.critic = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.Tanh(),
            nn.Linear(256, 256),
            nn.Tanh(),
            nn.Linear(256, 1),
        )

    def forward(self, states):
        logits = self.actor(states)
        values = self.critic(states).squeeze(-1)
        return logits, values

    def act(self, states, deterministic: bool = False):

        if states.ndim == 1:
            states = states.unsqueeze(0)

        logits, values = self.forward(states)
        distribution = Categorical(logits=logits)

        if deterministic:
            actions = torch.argmax(logits, dim=-1)
        else:
            actions = distribution.sample()

        log_probs = distribution.log_prob(actions)

        return actions, log_probs, values

    def evaluate_actions(self, states, actions):

        logits, values = self.forward(states)
        distribution = Categorical(logits=logits)

        log_probs = distribution.log_prob(actions)
        entropy = distribution.entropy()

        return log_probs, entropy, values


def checkpoint_payload(
    model: ActorCritic,
    state_normalization: Dict,
):
    return {
        "model_state_dict": model.state_dict(),
        "state_normalization": state_normalization,
        "feature_order": list(FEATURE_ORDER),
        "action_tiers": [tier.value for tier in TIER_ORDER],
        "clipping_rules": {
            "normalized_features": [0.0, 1.0],
            "out_of_range": "clip",
        },
    }


class FrozenTierPolicy:

    def __init__(
        self,
        model: ActorCritic,
        device: str = "cpu",
        state_normalization: Optional[Dict] = None,
    ):
        self.device = torch.device(device)
        self.model = model.to(self.device)
        self.model.eval()

        for parameter in self.model.parameters():
            parameter.requires_grad_(False)

        self.state_normalization = state_normalization

    @classmethod
    def load(
        cls,
        checkpoint_path,
        device: str = "cpu",
    ):

        path = Path(checkpoint_path)

        if not path.is_file():
            raise FileNotFoundError(str(path))

        try:
            checkpoint = torch.load(
                str(path),
                map_location=device,
                weights_only=True,
            )
        except TypeError:
            checkpoint = torch.load(
                str(path),
                map_location=device,
            )

        required = {
            "model_state_dict",
            "state_normalization",
            "feature_order",
            "action_tiers",
        }

        missing = required.difference(checkpoint)

        if missing:
            raise ValueError(
                "Incomplete policy checkpoint: {}".format(
                    sorted(missing)
                )
            )

        if checkpoint["feature_order"] != list(FEATURE_ORDER):
            raise ValueError("Checkpoint feature order mismatch.")

        expected_actions = [tier.value for tier in TIER_ORDER]

        if checkpoint["action_tiers"] != expected_actions:
            raise ValueError("Checkpoint action encoding mismatch.")

        model = ActorCritic()
        model.load_state_dict(checkpoint["model_state_dict"])

        return cls(
            model=model,
            device=device,
            state_normalization=checkpoint["state_normalization"],
        )

    @torch.no_grad()
    def predict(self, state):

        if len(state) != STATE_DIM:
            raise ValueError("Expected an 11-dimensional state.")

        tensor = torch.as_tensor(
            state,
            dtype=torch.float32,
            device=self.device,
        ).unsqueeze(0)

        logits, _ = self.model(tensor)

        action = int(torch.argmax(logits, dim=-1).item())

        return TIER_ORDER[action]
