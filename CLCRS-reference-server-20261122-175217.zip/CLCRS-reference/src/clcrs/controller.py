"""
CLCRS online control-path reference implementation.

The controller implements:
    Event Gate
    Feasibility filtering
    Single-tier PPO bypass
    P99 latency admission
    Frozen-policy inference
    Deadline validation
    Physical-node resolution
    Capacity reservation
    NUMA policy execution interface
    Native-runtime fallback

It does not implement active page migration.

Platform-specific Linux NUMA execution is injected through
NumaExecutor. The original offloading runtime is injected
through NativeRuntime.
"""

from dataclasses import dataclass
from threading import RLock
from time import perf_counter_ns
from typing import Any, Callable, Optional, Protocol

from .latency_budget import LatencyBudget
from .resolver import TierResolver
from .state import (
    PlacementRequest,
    RuntimeSnapshot,
    StateBuilder,
)
from .topology import Tier, TierMap


@dataclass(frozen=True)
class RuntimePlacementRequest:
    address: int
    placement: PlacementRequest

    def __post_init__(self):
        if int(self.address) <= 0:
            raise ValueError("Invalid host-buffer address")


@dataclass(frozen=True)
class ControllerResult:
    status: str
    path: str
    reason: str
    tier: Optional[str]
    node_id: Optional[int]
    reservation_token: Optional[int]
    control_elapsed_ns: int
    native_result: Any = None


class TierPolicy(Protocol):

    def predict(self, state):
        ...


class NumaExecutor(Protocol):

    def apply_policy(
        self,
        address: int,
        size_bytes: int,
        node_id: int,
    ) -> bool:
        ...


class NativeRuntime(Protocol):

    def fallback(
        self,
        request: RuntimePlacementRequest,
        reason: str,
    ):
        ...


class CLCRSController:

    def __init__(
        self,
        state_builder: StateBuilder,
        policy: Optional[TierPolicy],
        latency_budget: LatencyBudget,
        executor: NumaExecutor,
        native_runtime: NativeRuntime,
        resolver: Optional[TierResolver] = None,
        snapshot_lock=None,
        clock_ns: Callable = perf_counter_ns,
    ):
        self.state_builder = state_builder
        self.policy = policy
        self.latency_budget = latency_budget
        self.executor = executor
        self.native_runtime = native_runtime
        self.resolver = resolver or TierResolver()

        self.lock = snapshot_lock or RLock()
        self.clock_ns = clock_ns

        self._next_token = 1
        self._pending = {}

    def _elapsed(self, started):
        return max(
            0,
            int(self.clock_ns()) - int(started)
        )

    def _fallback(
        self,
        request,
        reason,
        started,
        tier=None,
        node_id=None,
        elapsed_ns=None,
    ):
        native_result = self.native_runtime.fallback(
            request,
            reason,
        )

        if elapsed_ns is None:
            elapsed_ns = self._elapsed(started)

        return ControllerResult(
            status="fallback",
            path="native_fallback",
            reason=str(reason),
            tier=tier.value if tier is not None else None,
            node_id=node_id,
            reservation_token=None,
            control_elapsed_ns=int(elapsed_ns),
            native_result=native_result,
        )

    def place(
        self,
        runtime_request: RuntimePlacementRequest,
        snapshot: RuntimeSnapshot,
        tier_map: TierMap,
    ) -> ControllerResult:

        started = int(self.clock_ns())
        request = runtime_request.placement

        # --------------------------------------------
        # 1. Initial feasibility check
        # --------------------------------------------

        try:
            with self.lock:
                initial_feasible = self.resolver.feasible_tiers(
                    snapshot,
                    tier_map,
                    request,
                )
        except Exception:
            return self._fallback(
                runtime_request,
                "runtime_snapshot_invalid",
                started,
            )

        if not initial_feasible:
            return self._fallback(
                runtime_request,
                "no_feasible_tier",
                started,
            )

        deadline = None

        # --------------------------------------------
        # 2. One feasible tier: bypass PPO
        # --------------------------------------------

        if len(initial_feasible) == 1:

            selected_tier = initial_feasible[0]
            decision_path = "single_tier_bypass"

        # --------------------------------------------
        # 3. Multiple tiers: budget + frozen PPO
        # --------------------------------------------

        else:

            budget = self.latency_budget.evaluate(
                request.aligned_size_bytes
            )

            if not budget.admitted:
                return self._fallback(
                    runtime_request,
                    "budget_" + budget.reason,
                    started,
                )

            deadline = started + budget.budget_ns

            try:
                with self.lock:
                    observation = self.state_builder.build(
                        snapshot,
                        tier_map,
                        request,
                    ).values
            except Exception:
                return self._fallback(
                    runtime_request,
                    "state_construction_failed",
                    started,
                )

            if int(self.clock_ns()) >= deadline:
                return self._fallback(
                    runtime_request,
                    "deadline_after_state",
                    started,
                )

            if self.policy is None:
                return self._fallback(
                    runtime_request,
                    "frozen_policy_unavailable",
                    started,
                )

            try:
                action = self.policy.predict(observation)

                selected_tier = self.resolver.action_to_tier(
                    action
                )

            except Exception:
                return self._fallback(
                    runtime_request,
                    "policy_inference_failed",
                    started,
                )

            if int(self.clock_ns()) >= deadline:
                return self._fallback(
                    runtime_request,
                    "deadline_after_inference",
                    started,
                    tier=selected_tier,
                )

            if selected_tier not in initial_feasible:
                return self._fallback(
                    runtime_request,
                    "selected_tier_not_initially_feasible",
                    started,
                    tier=selected_tier,
                )

            decision_path = "frozen_ppo"

        # --------------------------------------------
        # 4. Revalidate + resolve + reserve atomically
        # --------------------------------------------

        failure = None
        resolution = None
        token = None
        control_elapsed = 0

        with self.lock:
            try:
                current_feasible = self.resolver.feasible_tiers(
                    snapshot,
                    tier_map,
                    request,
                )

                if selected_tier not in current_feasible:
                    failure = "selected_tier_lost_feasibility"

                else:
                    resolution = self.resolver.resolve(
                        selected_tier,
                        snapshot,
                        tier_map,
                        request,
                    )

                    if resolution is None:
                        failure = "node_resolution_failed"

                    else:
                        now = int(self.clock_ns())
                        control_elapsed = max(0, now - started)

                        if (
                            deadline is not None
                            and now >= deadline
                        ):
                            failure = "deadline_after_resolution"

                        elif not self.resolver.reserve_inflight(
                            snapshot,
                            resolution.node_id,
                            request.aligned_size_bytes,
                        ):
                            failure = "capacity_reservation_failed"

                        else:
                            token = self._next_token
                            self._next_token += 1

                            self._pending[token] = (
                                snapshot,
                                resolution.node_id,
                                request.aligned_size_bytes,
                            )

            except Exception:
                failure = "revalidation_failed"

        if failure is not None:
            return self._fallback(
                runtime_request,
                failure,
                started,
                tier=selected_tier,
                node_id=(
                    resolution.node_id
                    if resolution is not None
                    else None
                ),
            )

        # --------------------------------------------
        # 5. NUMA policy setup
        # --------------------------------------------

        try:
            applied = bool(
                self.executor.apply_policy(
                    runtime_request.address,
                    request.aligned_size_bytes,
                    resolution.node_id,
                )
            )
        except Exception:
            applied = False

        if not applied:
            self.cancel_reservation(token)

            return self._fallback(
                runtime_request,
                "numa_policy_setup_failed",
                started,
                tier=selected_tier,
                node_id=resolution.node_id,
                elapsed_ns=control_elapsed,
            )

        return ControllerResult(
            status="placed",
            path=decision_path,
            reason="placement_policy_set",
            tier=resolution.tier.value,
            node_id=resolution.node_id,
            reservation_token=token,
            control_elapsed_ns=control_elapsed,
        )

    # ------------------------------------------------
    # Reservation lifecycle
    # ------------------------------------------------

    def cancel_reservation(self, token: int) -> bool:

        with self.lock:
            entry = self._pending.get(token)

            if entry is None:
                return False

            snapshot, node_id, size_bytes = entry

            self.resolver.release_inflight(
                snapshot,
                node_id,
                size_bytes,
            )

            del self._pending[token]

            return True

    def notify_materialized(
        self,
        token: int,
        observed_free_bytes: int,
    ) -> bool:
        """
        Call only after physical-page materialization and
        a refreshed NUMA free-capacity observation.

        The observed free capacity replaces the stale value.
        The in-flight reservation is then retired.
        """

        observed_free_bytes = int(observed_free_bytes)

        if observed_free_bytes < 0:
            raise ValueError("Invalid observed free capacity")

        with self.lock:
            entry = self._pending.get(token)

            if entry is None:
                raise KeyError("Unknown reservation token")

            snapshot, node_id, size_bytes = entry

            state = snapshot.node_states.get(node_id)

            if state is None:
                raise RuntimeError(
                    "Reserved NUMA node disappeared"
                )

            if state.inflight_bytes < size_bytes:
                raise RuntimeError(
                    "Reservation accounting is inconsistent"
                )

            state.free_bytes = observed_free_bytes

            self.resolver.release_inflight(
                snapshot,
                node_id,
                size_bytes,
            )

            del self._pending[token]

            return True

    @property
    def pending_reservations(self):
        with self.lock:
            return len(self._pending)
