from dataclasses import dataclass
from enum import Enum
from typing import Dict, Mapping, Optional, Sequence, Tuple


class Tier(str, Enum):
    LOCAL = "Local"
    NEAR = "Near"
    FAR = "Far"


TIER_ORDER = (Tier.LOCAL, Tier.NEAR, Tier.FAR)
ACTION_TO_TIER = {
    0: Tier.LOCAL,
    1: Tier.NEAR,
    2: Tier.FAR,
}


@dataclass(frozen=True)
class NodeTopology:
    node_id: int
    socket_id: int
    total_memory_bytes: int


@dataclass(frozen=True)
class GPUTopology:
    cuda_index: int
    numa_node: int
    pci_bus_id: Optional[str] = None


@dataclass(frozen=True)
class TierMap:
    gpu_index: int
    affinity_node: int
    tiers: Mapping[Tier, Tuple[int, ...]]
    distances: Mapping[int, int]
    nodes: Mapping[int, NodeTopology]

    def candidates(self, tier):
        return self.tiers[Tier(tier)]

    def distance(self, node_id):
        return self.distances[node_id]

    @property
    def distance_bounds(self):
        values = tuple(self.distances.values())
        if not values:
            raise ValueError("The GPU has no candidate NUMA nodes.")
        return min(values), max(values)

    @property
    def candidate_nodes(self):
        return tuple(sorted(self.distances))


def build_tier_map(
    gpu: GPUTopology,
    nodes: Sequence[NodeTopology],
    distance_matrix: Mapping[int, Mapping[int, int]],
) -> TierMap:

    node_map = {node.node_id: node for node in nodes}

    if len(node_map) != len(nodes):
        raise ValueError("Duplicate NUMA node IDs.")

    if gpu.numa_node not in node_map:
        raise ValueError("GPU affinity node does not exist.")

    row = distance_matrix.get(gpu.numa_node)

    if row is None:
        raise ValueError("Missing Linux NUMA distance row.")

    for node in nodes:
        if node.total_memory_bytes <= 0:
            raise ValueError("Invalid NUMA memory capacity.")

        if node.node_id not in row:
            raise ValueError(
                "Missing NUMA distance for node {}".format(node.node_id)
            )

    source_socket = node_map[gpu.numa_node].socket_id

    local = (gpu.numa_node,)

    near = tuple(sorted(
        node.node_id
        for node in nodes
        if node.socket_id == source_socket
        and node.node_id != gpu.numa_node
    ))

    far = tuple(sorted(
        node.node_id
        for node in nodes
        if node.socket_id != source_socket
    ))

    tiers = {
        Tier.LOCAL: local,
        Tier.NEAR: near,
        Tier.FAR: far,
    }

    distances = {
        node.node_id: int(row[node.node_id])
        for node in nodes
    }

    return TierMap(
        gpu_index=gpu.cuda_index,
        affinity_node=gpu.numa_node,
        tiers=tiers,
        distances=distances,
        nodes=node_map,
    )
