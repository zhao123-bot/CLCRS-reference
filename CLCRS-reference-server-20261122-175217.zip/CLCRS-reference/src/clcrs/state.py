from dataclasses import dataclass, field
from typing import Callable, Dict, Mapping, Optional, Tuple

from .topology import TIER_ORDER, Tier, TierMap


FEATURE_ORDER = (
    "h_L", "h_N", "h_F",
    "d_L", "d_N", "d_F",
    "p_L", "p_N", "p_F",
    "z_S", "z_P",
)


def clip01(value):
    return min(1.0, max(0.0, float(value)))


@dataclass
class NodeRuntimeState:
    node_id: int
    free_bytes: int
    guard_bytes: int
    inflight_bytes: int = 0
    online: bool = True
    allowed: bool = True

    @property
    def effective_capacity_bytes(self):
        return (
            self.free_bytes
            - self.guard_bytes
            - self.inflight_bytes
        )


@dataclass
class RuntimeSnapshot:
    node_states: Dict[int, NodeRuntimeState]
    path_pressure: Dict[Tuple[int, int], float] = field(
        default_factory=dict
    )
    version: int = 0


@dataclass(frozen=True)
class PlacementRequest:
    object_id: str
    requested_size_bytes: int
    aligned_size_bytes: int
    gpu_index: int
    priority_level: int

    def __post_init__(self):
        if not self.object_id:
            raise ValueError("object_id cannot be empty.")

        if self.requested_size_bytes <= 0:
            raise ValueError("Invalid requested size.")

        if self.aligned_size_bytes < self.requested_size_bytes:
            raise ValueError("Invalid aligned size.")

        if self.priority_level not in (0, 1, 2):
            raise ValueError("Priority must be Low, Normal, or High.")


class MissingTierRepresentative(RuntimeError):
    pass


class SizeNormalizer:
    def __init__(self, transform: Callable[[int], float]):
        self.transform = transform

    def normalize(self, size_bytes):
        value = float(self.transform(size_bytes))

        if not 0.0 <= value <= 1.0:
            raise ValueError(
                "Normalized object size must be within [0, 1]."
            )

        return value


@dataclass(frozen=True)
class Representative:
    node_id: int
    effective_capacity_bytes: int
    post_allocation_headroom_bytes: int


@dataclass(frozen=True)
class StateObservation:
    values: Tuple[float, ...]
    representatives: Mapping[Tier, Representative]
    feasible_tiers: Tuple[Tier, ...]


def compute_path_pressure(observed_bandwidth, idle_bandwidth):
    if idle_bandwidth <= 0:
        raise ValueError("Idle bandwidth must be positive.")

    if observed_bandwidth < 0:
        raise ValueError("Observed bandwidth cannot be negative.")

    return clip01(
        1.0 - observed_bandwidth / idle_bandwidth
    )


def select_representative_node(
    snapshot: RuntimeSnapshot,
    tier_map: TierMap,
    tier: Tier,
    aligned_size_bytes: int,
) -> Optional[Representative]:

    candidates = []

    for node_id in tier_map.candidates(tier):
        state = snapshot.node_states.get(node_id)

        if state is None or not state.online or not state.allowed:
            continue

        effective = state.effective_capacity_bytes
        headroom = effective - aligned_size_bytes

        candidates.append((
            -headroom,
            tier_map.distance(node_id),
            node_id,
            effective,
        ))

    if not candidates:
        return None

    candidates.sort(key=lambda item: (item[0], item[1], item[2]))

    _, _, node_id, effective = candidates[0]

    return Representative(
        node_id=node_id,
        effective_capacity_bytes=effective,
        post_allocation_headroom_bytes=(
            effective - aligned_size_bytes
        ),
    )


class StateBuilder:

    def __init__(self, size_normalizer: SizeNormalizer):
        self.size_normalizer = size_normalizer

    def build(
        self,
        snapshot: RuntimeSnapshot,
        tier_map: TierMap,
        request: PlacementRequest,
    ) -> StateObservation:

        if request.gpu_index != tier_map.gpu_index:
            raise ValueError("Requesting GPU does not match Tier Map.")

        d_min, d_max = tier_map.distance_bounds

        h_features = []
        d_features = []
        p_features = []

        representatives = {}
        feasible = []

        for tier in TIER_ORDER:

            representative = select_representative_node(
                snapshot,
                tier_map,
                tier,
                request.aligned_size_bytes,
            )

            if representative is None:
                raise MissingTierRepresentative(
                    "No online, process-allowed node in tier {}".format(
                        tier.value
                    )
                )

            node_id = representative.node_id
            node_state = snapshot.node_states[node_id]
            node_topology = tier_map.nodes[node_id]

            usable_capacity = (
                node_topology.total_memory_bytes
                - node_state.guard_bytes
            )

            if usable_capacity <= 0:
                raise ValueError("Invalid usable NUMA capacity.")

            h = clip01(
                representative.effective_capacity_bytes
                / usable_capacity
            )

            if d_max == d_min:
                d = 0.0
            else:
                d = clip01(
                    (tier_map.distance(node_id) - d_min)
                    / (d_max - d_min)
                )

            pressure_key = (request.gpu_index, node_id)

            if pressure_key not in snapshot.path_pressure:
                raise KeyError(
                    "Missing GPU-NUMA path pressure: {}".format(
                        pressure_key
                    )
                )

            p = float(snapshot.path_pressure[pressure_key])

            if not 0.0 <= p <= 1.0:
                raise ValueError("Path pressure must be in [0, 1].")

            h_features.append(h)
            d_features.append(d)
            p_features.append(p)

            representatives[tier] = representative

            if (
                representative.effective_capacity_bytes
                >= request.aligned_size_bytes
            ):
                feasible.append(tier)

        z_size = self.size_normalizer.normalize(
            request.requested_size_bytes
        )

        z_priority = request.priority_level / 2.0

        values = tuple(
            h_features
            + d_features
            + p_features
            + [z_size, z_priority]
        )

        if len(values) != 11:
            raise RuntimeError("Invalid CLCRS state dimension.")

        return StateObservation(
            values=values,
            representatives=representatives,
            feasible_tiers=tuple(feasible),
        )
