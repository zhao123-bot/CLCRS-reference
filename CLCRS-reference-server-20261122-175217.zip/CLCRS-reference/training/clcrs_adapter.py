"""
CLCRS reference-training adapter.

Connects:
    JSONL lifecycle traces
        -> OfflinePlacementEnvironment
        -> 11-D StateBuilder
        -> TierResolver
        -> RewardModel
        -> PPO training interface

One RL decision is generated for each object creation.
Access events update GPU-NUMA path pressure.
Release events restore the corresponding capacity.

No active page migration is implemented.
"""

import json
import math
from pathlib import Path

import yaml

from clcrs.environment import OfflinePlacementEnvironment
from clcrs.reward import (
    RewardConfig,
    RewardModel,
    RewardNormalization,
)
from clcrs.state import (
    FEATURE_ORDER,
    NodeRuntimeState,
    PlacementRequest,
    RuntimeSnapshot,
    SizeNormalizer,
    StateBuilder,
)
from clcrs.topology import (
    GPUTopology,
    NodeTopology,
    build_tier_map,
)

from training.trace_io import load_jsonl


ROOT = Path(__file__).resolve().parents[1]

_NORMALIZATION_CACHE = None
_CONFIG_CACHE = None


# ------------------------------------------------------------
# Configuration and profile loading
# ------------------------------------------------------------

def _load_config():
    global _CONFIG_CACHE

    if _CONFIG_CACHE is None:
        path = ROOT / "configs" / "ppo.yaml"

        with path.open("r", encoding="utf-8") as stream:
            _CONFIG_CACHE = yaml.safe_load(stream)

    return _CONFIG_CACHE


def _load_manifest(path):
    path = Path(path).resolve()

    if not path.is_file():
        raise FileNotFoundError(str(path))

    with path.open("r", encoding="utf-8") as stream:
        manifest = json.load(stream)

    if not isinstance(manifest, dict):
        raise TypeError("Profile manifest must be a JSON object")

    if int(manifest.get("schema_version", 0)) != 1:
        raise ValueError("Unsupported profile schema version")

    required = (
        "profile_id",
        "split",
        "trace_file",
        "allocation_alignment_bytes",
        "topology",
        "runtime",
        "calibration",
    )

    missing = [key for key in required if key not in manifest]

    if missing:
        raise ValueError(
            "Missing profile fields: " + ", ".join(missing)
        )

    return manifest


def _resolve_trace_path(manifest):
    path = Path(manifest["trace_file"])

    if not path.is_absolute():
        path = ROOT / path

    path = path.resolve()

    if not path.is_file():
        raise FileNotFoundError(
            "Trace file does not exist: " + str(path)
        )

    return path


def _profile_paths(folder):
    directory = ROOT / "data" / folder

    if not directory.exists():
        return []

    return [
        str(path.resolve())
        for path in sorted(directory.glob("*.json"))
        if path.is_file()
    ]


def training_profiles():
    return _profile_paths("training")


def validation_profiles():
    return _profile_paths("validation")


# ------------------------------------------------------------
# Training-only normalization
# ------------------------------------------------------------

def fit_normalization(profile_paths):
    """
    Fit normalization exclusively from training profiles.

    Size:
        max requested object size in training traces.

    Pressure:
        min/max of transformed training calibration samples.

    Validation profiles are never used here.
    """

    profile_paths = list(profile_paths)

    if not profile_paths:
        raise RuntimeError(
            "No training profiles found in data/training/"
        )

    config = _load_config()

    epsilon = float(
        config["reward"]["runtime_path_pressure_penalty"][
            "epsilon_press"
        ]
    )

    if epsilon <= 0:
        raise ValueError("Invalid pressure epsilon")

    max_size = 0
    transformed_samples = []

    for profile_path in profile_paths:
        manifest = _load_manifest(profile_path)

        if manifest["split"] != "train":
            raise ValueError(
                "Normalization can only use training profiles"
            )

        events = load_jsonl(
            _resolve_trace_path(manifest)
        )

        sizes = [
            event.size_bytes
            for event in events
            if event.event == "create"
        ]

        if not sizes:
            raise ValueError(
                "Training profile has no create events: "
                + str(profile_path)
            )

        max_size = max(max_size, max(sizes))

        samples = manifest["calibration"].get(
            "pressure_samples", []
        )

        if not samples:
            raise ValueError(
                "Missing calibration.pressure_samples in "
                + str(profile_path)
            )

        for sample in samples:
            pressure = float(sample)

            if (
                not math.isfinite(pressure)
                or not 0.0 <= pressure <= 1.0
            ):
                raise ValueError(
                    "Pressure calibration must be within [0,1]"
                )

            transformed = pressure / (
                1.0 - pressure + epsilon
            )

            transformed_samples.append(transformed)

    if max_size <= 0:
        raise ValueError("Invalid training size range")

    lower = min(transformed_samples)
    upper = max(transformed_samples)

    if upper <= lower:
        raise ValueError(
            "Training pressure samples have no usable range"
        )

    return {
        "source": "training_profiles",
        "size_max_bytes": int(max_size),
        "pressure_lower": float(lower),
        "pressure_upper": float(upper),
        "pressure_epsilon": epsilon,
        "feature_order": list(FEATURE_ORDER),
    }


def normalization_parameters():
    global _NORMALIZATION_CACHE

    if _NORMALIZATION_CACHE is None:
        _NORMALIZATION_CACHE = fit_normalization(
            training_profiles()
        )

    return dict(_NORMALIZATION_CACHE)


# ------------------------------------------------------------
# Trace-driven episode environment
# ------------------------------------------------------------

class TraceEpisodeEnvironment:

    def __init__(
        self,
        base_environment,
        events,
        gpu_index,
        alignment_bytes,
        idle_bandwidth,
        pressure_source,
        profile_id,
    ):
        self.base = base_environment
        self.events = list(events)

        self.gpu_index = int(gpu_index)
        self.alignment_bytes = int(alignment_bytes)

        self.idle_bandwidth = dict(idle_bandwidth)
        self.pressure_source = str(pressure_source)
        self.profile_id = str(profile_id)

        self.cursor = 0
        self.current_request = None
        self.current_create_timestamp = None

        self.active_meta = {}
        self.last_path_timestamp = {}

    def reset(self):
        self.base.reset()

        self.cursor = 0
        self.current_request = None
        self.current_create_timestamp = None

        self.active_meta = {}
        self.last_path_timestamp = {}

        observation = self._advance_to_next_create()

        if observation is None:
            raise ValueError(
                "Trace contains no object creation event: "
                + self.profile_id
            )

        return observation

    def _advance_to_next_create(self):

        while self.cursor < len(self.events):

            event = self.events[self.cursor]
            self.cursor += 1

            # --------------------------------------------
            # Object creation: next RL decision
            # --------------------------------------------

            if event.event == "create":

                if event.gpu_id != self.gpu_index:
                    raise ValueError(
                        "Trace GPU does not match profile GPU"
                    )

                if (
                    event.object_id in self.active_meta
                    or event.object_id in self.base.active_objects
                ):
                    raise ValueError(
                        "Duplicate active object: "
                        + event.object_id
                    )

                size = int(event.size_bytes)

                aligned = (
                    (size + self.alignment_bytes - 1)
                    // self.alignment_bytes
                ) * self.alignment_bytes

                self.current_request = PlacementRequest(
                    object_id=event.object_id,
                    requested_size_bytes=size,
                    aligned_size_bytes=aligned,
                    gpu_index=event.gpu_id,
                    priority_level=event.priority,
                )

                self.current_create_timestamp = (
                    event.timestamp_ns
                )

                return list(
                    self.base.state_for(
                        self.current_request
                    ).values
                )

            # --------------------------------------------
            # Access: update runtime path pressure
            # --------------------------------------------

            if event.event == "access":

                meta = self.active_meta.get(
                    event.object_id
                )

                if meta is None:
                    raise ValueError(
                        "Access to an inactive object: "
                        + event.object_id
                    )

                gpu = meta["gpu_index"]
                node = meta["node_id"]

                key = (gpu, node)

                idle = self.idle_bandwidth[node]

                if (
                    event.observed_bandwidth_bytes_per_sec
                    is not None
                ):
                    observed = (
                        event.observed_bandwidth_bytes_per_sec
                    )

                elif self.pressure_source == (
                    "trace_derived_throughput"
                ):
                    previous = self.last_path_timestamp.get(
                        key,
                        meta["created_ns"],
                    )

                    elapsed_ns = (
                        event.timestamp_ns - previous
                    )

                    if elapsed_ns <= 0:
                        observed = idle
                    else:
                        observed = (
                            event.transferred_bytes
                            * 1_000_000_000
                            / elapsed_ns
                        )

                else:
                    raise ValueError(
                        "Measured path-pressure profile requires "
                        "observed_bandwidth_bytes_per_sec "
                        "for every access event"
                    )

                self.base.observe_path_bandwidth(
                    gpu,
                    node,
                    observed,
                    idle,
                )

                self.last_path_timestamp[key] = (
                    event.timestamp_ns
                )

                continue

            # --------------------------------------------
            # Release: restore capacity
            # --------------------------------------------

            if event.event == "release":

                if event.object_id not in self.active_meta:
                    raise ValueError(
                        "Release of an inactive object: "
                        + event.object_id
                    )

                released = self.base.release_object(
                    event.object_id
                )

                if not released:
                    raise RuntimeError(
                        "Base environment failed to release object"
                    )

                del self.active_meta[event.object_id]

                continue

        self.current_request = None
        self.current_create_timestamp = None

        return None

    def step(self, action):

        if self.current_request is None:
            raise RuntimeError(
                "No pending placement request"
            )

        request = self.current_request
        create_timestamp = self.current_create_timestamp

        result = self.base.step(
            request=request,
            action=int(action),
        )

        info = dict(result.info)

        # --------------------------------------------
        # Infeasible action terminates this episode
        # --------------------------------------------

        if info.get("infeasible", False):

            self.current_request = None
            self.current_create_timestamp = None

            info.update({
                "capacity_feasible": False,
                "infeasible_action": True,
                "profile_id": self.profile_id,
            })

            return (
                None,
                float(result.reward),
                True,
                info,
            )

        # --------------------------------------------
        # Record physical allocation
        # --------------------------------------------

        node_id = int(info["node_id"])

        self.active_meta[request.object_id] = {
            "gpu_index": request.gpu_index,
            "node_id": node_id,
            "created_ns": create_timestamp,
        }

        path_key = (request.gpu_index, node_id)

        self.last_path_timestamp.setdefault(
            path_key,
            create_timestamp,
        )

        self.current_request = None
        self.current_create_timestamp = None

        # Process subsequent accesses/releases until
        # the next object creation or trace termination.

        next_observation = self._advance_to_next_create()

        terminated = next_observation is None

        info.update({
            "capacity_feasible": True,
            "infeasible_action": False,
            "profile_id": self.profile_id,
            "trace_exhausted": terminated,
        })

        return (
            next_observation,
            float(result.reward),
            terminated,
            info,
        )


# ------------------------------------------------------------
# Construct real CLCRS modules from one profile
# ------------------------------------------------------------

def _build_environment_from_manifest(
    profile,
    split,
    normalization,
):

    manifest = _load_manifest(profile)

    if manifest["split"] != split:
        raise ValueError(
            "Profile split mismatch: expected {}, got {}".format(
                split,
                manifest["split"],
            )
        )

    topology_cfg = manifest["topology"]
    runtime_cfg = manifest["runtime"]

    gpu_cfg = topology_cfg["gpu"]

    gpu = GPUTopology(
        cuda_index=int(gpu_cfg["cuda_index"]),
        numa_node=int(gpu_cfg["numa_node"]),
        pci_bus_id=gpu_cfg.get("pci_bus_id"),
    )

    nodes = [
        NodeTopology(
            node_id=int(item["node_id"]),
            socket_id=int(item["socket_id"]),
            total_memory_bytes=int(
                item["total_memory_bytes"]
            ),
        )
        for item in topology_cfg["nodes"]
    ]

    distance_matrix = {
        int(source): {
            int(destination): int(distance)
            for destination, distance in row.items()
        }
        for source, row in topology_cfg[
            "distance_matrix"
        ].items()
    }

    tier_map = build_tier_map(
        gpu=gpu,
        nodes=nodes,
        distance_matrix=distance_matrix,
    )

    # --------------------------------------------
    # Runtime capacity
    # --------------------------------------------

    runtime_nodes = {}

    for item in runtime_cfg["nodes"]:

        node_id = int(item["node_id"])

        if node_id in runtime_nodes:
            raise ValueError("Duplicate runtime node")

        free_bytes = int(item["free_bytes"])
        guard_bytes = int(item["guard_bytes"])
        inflight_bytes = int(
            item.get("inflight_bytes", 0)
        )

        if min(
            free_bytes,
            guard_bytes,
            inflight_bytes,
        ) < 0:
            raise ValueError(
                "Negative runtime capacity field"
            )

        runtime_nodes[node_id] = NodeRuntimeState(
            node_id=node_id,
            free_bytes=free_bytes,
            guard_bytes=guard_bytes,
            inflight_bytes=inflight_bytes,
            online=bool(item["online"]),
            allowed=bool(item["allowed"]),
        )

    topology_ids = {
        node.node_id for node in nodes
    }

    if set(runtime_nodes) != topology_ids:
        raise ValueError(
            "Topology and runtime node sets differ"
        )

    # --------------------------------------------
    # GPU-NUMA idle bandwidth calibration
    # --------------------------------------------

    idle_bandwidth = {}
    path_pressure = {}

    expected_paths = {
        (gpu.cuda_index, node_id)
        for node_id in topology_ids
    }

    for item in runtime_cfg["path_calibration"]:

        gpu_index = int(item["gpu_index"])
        node_id = int(item["node_id"])

        key = (gpu_index, node_id)

        if key not in expected_paths:
            raise ValueError(
                "Unexpected GPU-NUMA calibration path"
            )

        if key in path_pressure:
            raise ValueError(
                "Duplicate GPU-NUMA calibration path"
            )

        idle = float(
            item["idle_bandwidth_bytes_per_sec"]
        )

        if not math.isfinite(idle) or idle <= 0:
            raise ValueError(
                "Idle bandwidth must be positive"
            )

        idle_bandwidth[node_id] = idle

        # Initial observed bandwidth equals calibrated
        # idle bandwidth, therefore initial pressure = 0.

        path_pressure[key] = 0.0

    if set(path_pressure) != expected_paths:
        raise ValueError(
            "Missing GPU-NUMA path calibration"
        )

    pressure_source = runtime_cfg[
        "path_pressure_source"
    ]

    if pressure_source not in (
        "measured_access_bandwidth",
        "trace_derived_throughput",
    ):
        raise ValueError(
            "Unsupported path_pressure_source"
        )

    snapshot = RuntimeSnapshot(
        node_states=runtime_nodes,
        path_pressure=path_pressure,
    )

    # --------------------------------------------
    # Frozen training-derived state normalization
    # --------------------------------------------

    size_max = int(
        normalization["size_max_bytes"]
    )

    if size_max <= 0:
        raise ValueError(
            "Invalid training size normalization"
        )

    size_normalizer = SizeNormalizer(
        lambda size: min(
            1.0,
            float(size) / size_max,
        )
    )

    state_builder = StateBuilder(
        size_normalizer=size_normalizer
    )

    # --------------------------------------------
    # Reward model: exact PPO configuration
    # --------------------------------------------

    config = _load_config()
    reward_cfg = config["reward"]

    weights = reward_cfg["weights"]

    capacity_cfg = reward_cfg["capacity_penalty"]
    pressure_cfg = reward_cfg[
        "runtime_path_pressure_penalty"
    ]

    reward_model = RewardModel(
        normalization=RewardNormalization(
            pressure_lower=float(
                normalization["pressure_lower"]
            ),
            pressure_upper=float(
                normalization["pressure_upper"]
            ),
        ),
        config=RewardConfig(
            base_reward=float(
                reward_cfg["base_reward"]
            ),
            terminal_reward=float(
                reward_cfg["terminal_reward"]
            ),
            alpha=float(weights["alpha"]),
            beta=float(weights["beta"]),
            gamma_press=float(
                weights["gamma_press"]
            ),
            lambda_cap=float(
                capacity_cfg["lambda_cap"]
            ),
            epsilon_press=float(
                pressure_cfg["epsilon_press"]
            ),
        ),
    )

    base_environment = OfflinePlacementEnvironment(
        initial_snapshot=snapshot,
        tier_map=tier_map,
        state_builder=state_builder,
        reward_model=reward_model,
    )

    alignment = int(
        manifest["allocation_alignment_bytes"]
    )

    if alignment <= 0:
        raise ValueError(
            "Invalid allocation alignment"
        )

    events = load_jsonl(
        _resolve_trace_path(manifest)
    )

    if not any(event.event == "create" for event in events):
        raise ValueError(
            "Profile contains no object creation events"
        )

    return TraceEpisodeEnvironment(
        base_environment=base_environment,
        events=events,
        gpu_index=gpu.cuda_index,
        alignment_bytes=alignment,
        idle_bandwidth=idle_bandwidth,
        pressure_source=pressure_source,
        profile_id=manifest["profile_id"],
    )


def build_environment(
    profile,
    split,
    normalization=None,
):

    if split not in ("train", "validation"):
        raise ValueError("Invalid split")

    if normalization is None:
        normalization = normalization_parameters()

    return _build_environment_from_manifest(
        profile=profile,
        split=split,
        normalization=normalization,
    )


# ------------------------------------------------------------
# PPO Actor-Critic
# ------------------------------------------------------------

def build_policy(state_dim, action_dim, seed):

    if int(state_dim) != 11:
        raise ValueError("CLCRS requires 11-D state")

    if int(action_dim) != 3:
        raise ValueError("CLCRS requires three tier actions")

    import torch

    torch.manual_seed(int(seed))

    # Lazy import: static validation does not require PyTorch.
    from clcrs.policy import ActorCritic

    return ActorCritic(
        state_dim=11,
        action_dim=3,
    )
