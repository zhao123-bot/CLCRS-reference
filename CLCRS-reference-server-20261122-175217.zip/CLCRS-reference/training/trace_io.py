import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class TraceEvent:
    timestamp_ns: int
    event: str
    object_id: str
    gpu_id: Optional[int] = None
    size_bytes: Optional[int] = None
    priority: Optional[int] = None
    direction: Optional[str] = None
    transferred_bytes: int = 0
    observed_bandwidth_bytes_per_sec: Optional[float] = None

    @classmethod
    def from_record(cls, record):
        timestamp = int(record["timestamp_ns"])
        event = str(record["event"]).lower()
        object_id = str(record["object_id"])

        if timestamp < 0 or not object_id:
            raise ValueError("Invalid timestamp or object_id")

        if event == "create":
            gpu_id = int(record["gpu_id"])
            size = int(record["size_bytes"])
            priority = int(record["priority"])

            if gpu_id < 0 or size <= 0 or priority not in (0, 1, 2):
                raise ValueError("Invalid creation metadata")

            return cls(
                timestamp_ns=timestamp,
                event=event,
                object_id=object_id,
                gpu_id=gpu_id,
                size_bytes=size,
                priority=priority,
            )

        if event == "access":
            direction = str(record["direction"]).upper()

            if direction == "MAPPED_MEMORY":
                direction = "MAPPED"

            amount = int(
                record.get(
                    "transferred_bytes",
                    record.get("bytes", 0)
                )
            )

            if direction not in ("H2D", "D2H", "MAPPED") or amount <= 0:
                raise ValueError("Invalid access metadata")

            observed = record.get(
                "observed_bandwidth_bytes_per_sec"
            )

            if observed is not None:
                observed = float(observed)

                if not math.isfinite(observed) or observed < 0:
                    raise ValueError(
                        "Invalid observed bandwidth"
                    )

            return cls(
                timestamp_ns=timestamp,
                event=event,
                object_id=object_id,
                direction=direction,
                transferred_bytes=amount,
                observed_bandwidth_bytes_per_sec=observed,
            )

        if event == "release":
            return cls(
                timestamp_ns=timestamp,
                event=event,
                object_id=object_id,
            )

        raise ValueError("Unknown event type: " + event)


def load_jsonl(path):
    events = []
    previous_timestamp = -1

    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue

            try:
                record = json.loads(line)
                event = TraceEvent.from_record(record)
            except Exception as exc:
                raise ValueError(
                    f"Invalid trace at line {line_number}: {exc}"
                ) from exc

            if event.timestamp_ns < previous_timestamp:
                raise ValueError(
                    "Trace events are not chronological"
                )

            previous_timestamp = event.timestamp_ns
            events.append(event)

    return events
