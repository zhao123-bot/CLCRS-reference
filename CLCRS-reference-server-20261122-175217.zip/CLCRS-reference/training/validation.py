def evaluate_policy(model, adapter, profiles, device,
                    max_steps=10000000):
    import torch

    if not profiles:
        raise ValueError("No validation profiles")

    previous_mode = model.training
    model.eval()

    returns = []
    all_feasible = True
    total_infeasible = 0
    total_steps = 0

    try:
        with torch.no_grad():
            for profile in profiles:
                env = adapter.build_environment(
                    profile, split="validation"
                )

                observation = env.reset()
                episode_return = 0.0
                terminated = False
                steps = 0

                while not terminated:
                    state = torch.as_tensor(
                        observation,
                        dtype=torch.float32,
                        device=device
                    ).reshape(1, -1)

                    if state.shape[-1] != 11:
                        raise ValueError("Expected 11-D state")

                    logits, _ = model(state)
                    action = int(
                        torch.argmax(logits, dim=-1).item()
                    )

                    observation, reward, terminated, info = env.step(action)

                    if not isinstance(info, dict):
                        raise TypeError("Environment info must be a dict")

                    if "capacity_feasible" not in info:
                        raise KeyError(
                            "Validation info must contain capacity_feasible"
                        )

                    all_feasible = (
                        all_feasible and bool(info["capacity_feasible"])
                    )

                    if bool(info.get("infeasible_action", False)):
                        total_infeasible += 1
                        all_feasible = False

                    episode_return += float(reward)
                    steps += 1
                    total_steps += 1

                    if steps >= max_steps:
                        raise RuntimeError(
                            "Validation episode did not terminate"
                        )

                returns.append(episode_return)

    finally:
        model.train(previous_mode)

    return {
        "mean_return": sum(returns) / len(returns),
        "capacity_feasible": all_feasible,
        "infeasible_actions": total_infeasible,
        "profile_count": len(returns),
        "steps": total_steps
    }
