"""
Compatibility entry point.

The actual CLCRS adapter is implemented in clcrs_adapter.py.
"""

from .clcrs_adapter import (
    training_profiles,
    validation_profiles,
    build_environment,
    build_policy,
    normalization_parameters,
)

__all__ = [
    "training_profiles",
    "validation_profiles",
    "build_environment",
    "build_policy",
    "normalization_parameters",
]
