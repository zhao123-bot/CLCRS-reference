import argparse
import importlib
import random
import shutil
from pathlib import Path

from training.ppo_core import compute_gae, ppo_update
from training.validation import evaluate_policy


FEATURE_ORDER = [
    "h_L", "h_N", "h_F",
    "d_L", "d_N", "d_F",
    "p_L", "p_N", "p_F",
    "z_S", "z_P"
]

ACTION_NAMES = ["Local", "Near", "Far"]


def check_adapter(adapter):
    required = (
        "training_profiles",
        "validation_profiles",
        "build_environment",
        "build_policy",
        "normalization_parameters"
    )

    missing = [name for name in required if not hasattr(adapter, name)]

    if missing:
        raise RuntimeError(
            "Adapter is missing: " + ", ".join(missing)
        )


def check_observation(observation):
    values = [float(x) for x in observation]

    if len(values) != 11:
        raise ValueError(
            f"Expected 11 state features, received {len(values)}"
        )

    return values


def collect_rollout(torch, adapter, profiles, profile_index,
                    env, observation, model, rollout_length,
                    device, gamma, gae_lambda):

    from torch.distributions import Categorical

    states = []
    actions = []
    log_probs = []
    rewards = []
    values = []
    dones = []

    last_done = False

    model.train()

    for _ in range(rollout_length):
        observation = check_observation(observation)

        state = torch.as_tensor(
            observation,
            dtype=torch.float32,
            device=device
        ).reshape(1, -1)

        with torch.no_grad():
            logits, value = model(state)
            distribution = Categorical(logits=logits)
            action = distribution.sample()
            log_prob = distribution.log_prob(action)

        action_id = int(action.item())

        next_observation, reward, terminated, info = env.step(action_id)

        if not isinstance(info, dict):
            raise TypeError("Environment info must be a dict")

        states.append(observation)
        actions.append(action_id)
        log_probs.append(float(log_prob.item()))
        rewards.append(float(reward))
        values.append(float(value.reshape(-1)[0].item()))
        dones.append(bool(terminated))

        last_done = bool(terminated)

        if terminated:
            profile_index = (profile_index + 1) % len(profiles)
            env = adapter.build_environment(
                profiles[profile_index], split="train"
            )
            observation = env.reset()
        else:
            observation = next_observation

    if last_done:
        next_value = 0.0
    else:
        next_state = torch.as_tensor(
            check_observation(observation),
            dtype=torch.float32,
            device=device
        ).reshape(1, -1)

        with torch.no_grad():
            _, value = model(next_state)
            next_value = float(value.reshape(-1)[0].item())

    advantages, returns = compute_gae(
        rewards, values, dones, next_value,
        gamma=gamma,
        gae_lambda=gae_lambda
    )

    batch = {
        "states": states,
        "actions": actions,
        "old_log_probs": log_probs,
        "advantages": advantages,
        "returns": returns
    }

    return batch, env, observation, profile_index


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--eval-interval", type=int, default=50000)
    args = parser.parse_args()

    import torch
    import yaml

    root = Path(__file__).resolve().parents[1]

    with (root / "configs/ppo.yaml").open(
        "r", encoding="utf-8"
    ) as stream:
        config = yaml.safe_load(stream)

    policy_cfg = config["policy"]
    ppo_cfg = policy_cfg["ppo"]
    training_cfg = config["training"]

    if policy_cfg["state"]["dimension"] != 11:
        raise ValueError("The paper configuration requires 11-D state")

    if policy_cfg["action"]["tiers"] != ACTION_NAMES:
        raise ValueError("Tier-action encoding mismatch")

    if not training_cfg["fixed_training_budget"]:
        raise ValueError("A fixed training budget is required")

    if training_cfg["early_stopping"]:
        raise ValueError("Early stopping is disabled in this configuration")

    adapter = importlib.import_module(args.adapter)
    check_adapter(adapter)

    train_profiles = list(adapter.training_profiles())
    validation_profiles = list(adapter.validation_profiles())

    if not train_profiles or not validation_profiles:
        raise RuntimeError("Training or validation profiles are empty")

    train_ids = {str(Path(p).resolve()) for p in train_profiles}
    validation_ids = {str(Path(p).resolve()) for p in validation_profiles}

    if train_ids.intersection(validation_ids):
        raise RuntimeError("Training and validation profiles overlap")

    normalization = adapter.normalization_parameters()

    if not isinstance(normalization, dict):
        raise TypeError("Normalization parameters must be a dictionary")

    if args.device == "auto":
        device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
    else:
        device = torch.device(args.device)

    total_steps = int(training_cfg["steps_per_seed"])
    seed_count = int(training_cfg["random_seed_count"])
    rollout_length = int(ppo_cfg["rollout_length"])
    initial_lr = float(
        policy_cfg["optimizer"]["initial_learning_rate"]
    )

    if args.eval_interval <= 0:
        raise ValueError("Evaluation interval must be positive")

    artifact_dir = root / "artifacts"
    artifact_dir.mkdir(parents=True, exist_ok=True)

    candidates = []

    for seed in range(seed_count):
        random.seed(seed)
        torch.manual_seed(seed)

        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        model = adapter.build_policy(
            state_dim=11,
            action_dim=3,
            seed=seed
        ).to(device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=initial_lr
        )

        profile_index = 0
        env = adapter.build_environment(
            train_profiles[profile_index], split="train"
        )
        observation = env.reset()

        steps = 0
        last_evaluation = 0
        best_return = float("-inf")
        best_path = artifact_dir / f"seed_{seed}_best.pt"

        print(f"SEED_START={seed}")

        while steps < total_steps:
            current_rollout = min(
                rollout_length, total_steps - steps
            )

            batch, env, observation, profile_index = collect_rollout(
                torch,
                adapter,
                train_profiles,
                profile_index,
                env,
                observation,
                model,
                current_rollout,
                device,
                float(ppo_cfg["discount_factor"]),
                float(ppo_cfg["gae_lambda"])
            )

            steps += current_rollout

            if policy_cfg["optimizer"]["learning_rate_schedule"] == "linear_decay":
                lr = initial_lr * max(
                    0.0, 1.0 - steps / total_steps
                )
                for group in optimizer.param_groups:
                    group["lr"] = lr

            metrics = ppo_update(
                model, optimizer, batch, ppo_cfg, device
            )

            if (
                steps - last_evaluation >= args.eval_interval
                or steps == total_steps
            ):
                result = evaluate_policy(
                    model, adapter, validation_profiles, device
                )

                print(
                    f"SEED={seed} STEP={steps} "
                    f"RETURN={result['mean_return']:.6f} "
                    f"FEASIBLE={result['capacity_feasible']} "
                    f"POLICY_LOSS={metrics['policy_loss']:.6f}"
                )

                if (
                    result["capacity_feasible"]
                    and result["mean_return"] > best_return
                ):
                    best_return = result["mean_return"]

                    torch.save({
                        "format_version": 1,
                        "policy_state_dict": model.state_dict(),
                        "model_state_dict": model.state_dict(),
                        "normalization": normalization,
                        "state_normalization": normalization,
                        "state_dim": 11,
                        "feature_order": FEATURE_ORDER,
                        "action_names": ACTION_NAMES,
                        "action_tiers": ACTION_NAMES,
                        "seed": seed,
                        "environment_steps": steps,
                        "validation": result,
                        "ppo_config": ppo_cfg
                    }, best_path)

                last_evaluation = steps

        if not best_path.is_file():
            raise RuntimeError(
                f"No capacity-feasible checkpoint for seed {seed}"
            )

        candidates.append({
            "seed": seed,
            "validation_return": best_return,
            "path": best_path
        })

        print(f"SEED_FINISHED={seed}")

    selected = max(
        candidates, key=lambda item: item["validation_return"]
    )

    final_path = artifact_dir / "final_policy.pt"
    shutil.copy2(selected["path"], final_path)

    print("TRAINING=PASS")
    print(f"SELECTED_SEED={selected['seed']}")
    print(f"VALIDATION_RETURN={selected['validation_return']}")
    print(f"FINAL_POLICY={final_path}")


if __name__ == "__main__":
    main()
