def compute_gae(rewards, values, dones, next_value,
                gamma=0.99, gae_lambda=0.95):

    if not (len(rewards) == len(values) == len(dones)):
        raise ValueError("Rollout fields have different lengths")

    advantages = [0.0] * len(rewards)
    gae = 0.0
    next_v = float(next_value)

    for i in reversed(range(len(rewards))):
        mask = 0.0 if dones[i] else 1.0

        delta = (
            float(rewards[i])
            + gamma * next_v * mask
            - float(values[i])
        )

        gae = delta + gamma * gae_lambda * mask * gae
        advantages[i] = gae
        next_v = float(values[i])

    returns = [
        advantage + float(value)
        for advantage, value in zip(advantages, values)
    ]

    return advantages, returns


def ppo_update(model, optimizer, batch, config, device):
    import torch
    import torch.nn.functional as F
    from torch.distributions import Categorical

    states = torch.as_tensor(
        batch["states"], dtype=torch.float32, device=device
    )
    actions = torch.as_tensor(
        batch["actions"], dtype=torch.long, device=device
    )
    old_log_probs = torch.as_tensor(
        batch["old_log_probs"], dtype=torch.float32, device=device
    )
    advantages = torch.as_tensor(
        batch["advantages"], dtype=torch.float32, device=device
    )
    returns = torch.as_tensor(
        batch["returns"], dtype=torch.float32, device=device
    )

    advantages = (
        advantages - advantages.mean()
    ) / advantages.std(unbiased=False).clamp_min(1e-8)

    clip = float(config["clip_parameter"])
    entropy_coef = float(config["entropy_coefficient"])
    minibatch_size = int(config["minibatch_size"])
    epochs = int(config["update_epochs"])

    policy_losses = []
    value_losses = []
    entropy_values = []

    count = len(actions)

    if count == 0:
        raise ValueError("Empty PPO rollout")

    for _ in range(epochs):
        permutation = torch.randperm(count, device=device)

        for start in range(0, count, minibatch_size):
            indices = permutation[start:start + minibatch_size]

            logits, values = model(states[indices])
            values = values.reshape(-1)

            distribution = Categorical(logits=logits)
            new_log_probs = distribution.log_prob(actions[indices])
            entropy = distribution.entropy().mean()

            ratio = torch.exp(
                new_log_probs - old_log_probs[indices]
            )

            surrogate_1 = ratio * advantages[indices]
            surrogate_2 = torch.clamp(
                ratio, 1.0 - clip, 1.0 + clip
            ) * advantages[indices]

            policy_loss = -torch.minimum(
                surrogate_1, surrogate_2
            ).mean()

            value_loss = F.mse_loss(
                values, returns[indices]
            )

            loss = (
                policy_loss
                + 0.5 * value_loss
                - entropy_coef * entropy
            )

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()

            policy_losses.append(float(policy_loss.detach().item()))
            value_losses.append(float(value_loss.detach().item()))
            entropy_values.append(float(entropy.detach().item()))

    return {
        "policy_loss": sum(policy_losses) / len(policy_losses),
        "value_loss": sum(value_losses) / len(value_losses),
        "entropy": sum(entropy_values) / len(entropy_values)
    }
