#!/usr/bin/env python3

import argparse
import csv
import datetime
import io
import json
import pathlib
import platform
import re
import subprocess


def run_command(args, timeout=30):
    try:
        p = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
            check=False,
        )
        return p.returncode, p.stdout
    except Exception as exc:
        return 127, str(exc)


def read_text(path):
    try:
        return pathlib.Path(path).read_text(
            encoding="utf-8",
            errors="replace",
        ).strip()
    except Exception:
        return ""


def parse_cpulist(value):
    result = set()

    for part in value.strip().split(","):
        if not part:
            continue

        if "-" in part:
            left, right = part.split("-", 1)
            a, b = int(left), int(right)

            if b < a:
                raise ValueError("Invalid CPU range")

            result.update(range(a, b + 1))
        else:
            result.add(int(part))

    return sorted(result)


def parse_node_meminfo(value, node_id):
    result = {}

    for key in ("MemTotal", "MemFree"):
        pattern = (
            r"Node\s+" + str(node_id)
            + r"\s+" + key + r":\s+(\d+)\s+kB"
        )

        match = re.search(pattern, value)

        if match:
            result[key.lower() + "_bytes"] = (
                int(match.group(1)) * 1024
            )

    return result


def parse_distance(value, node_ids):
    values = [int(x) for x in value.split()]
    result = {}

    for node_id in node_ids:
        if node_id < len(values):
            result[str(node_id)] = values[node_id]

    return result


def normalize_pci(value):
    value = value.strip().lower()

    if value.startswith("00000000:"):
        value = "0000:" + value[9:]

    return value


def cpu_socket(cpu_id):
    value = read_text(
        f"/sys/devices/system/cpu/cpu{cpu_id}/topology/"
        "physical_package_id"
    )

    return int(value) if value else None


def collect_nodes():
    base = pathlib.Path("/sys/devices/system/node")

    online_text = read_text(base / "online")

    if online_text:
        node_ids = parse_cpulist(online_text)
    else:
        node_ids = sorted(
            int(p.name[4:])
            for p in base.glob("node[0-9]*")
            if p.name[4:].isdigit()
        )

    nodes = []
    distance_matrix = {}

    for node_id in node_ids:
        directory = base / f"node{node_id}"

        meminfo = read_text(directory / "meminfo")
        memory = parse_node_meminfo(meminfo, node_id)

        total = memory.get("memtotal_bytes", 0)

        # Ignore nodes without host memory.
        if total <= 0:
            continue

        cpus = parse_cpulist(
            read_text(directory / "cpulist")
        )

        sockets = sorted({
            s for s in (cpu_socket(c) for c in cpus)
            if s is not None
        })

        socket_id = sockets[0] if len(sockets) == 1 else None

        nodes.append({
            "node_id": node_id,
            "socket_id": socket_id,
            "cpus": cpus,
            "total_memory_bytes": total,
            "memfree_bytes": memory.get(
                "memfree_bytes"
            ),
            "online": True,
            "socket_ids_observed": sockets,
        })

        distance_matrix[str(node_id)] = parse_distance(
            read_text(directory / "distance"),
            node_ids,
        )

    return nodes, distance_matrix


def collect_gpus():
    rc, output = run_command([
        "nvidia-smi",
        "--query-gpu=index,name,memory.total,pci.bus_id,driver_version",
        "--format=csv,noheader,nounits",
    ])

    if rc != 0:
        return [], output

    gpus = []

    for row in csv.reader(io.StringIO(output)):
        if len(row) < 5:
            continue

        index = int(row[0].strip())
        pci = normalize_pci(row[3])

        sysfs = pathlib.Path(
            "/sys/bus/pci/devices"
        ) / pci

        numa_text = read_text(sysfs / "numa_node")

        numa_node = (
            int(numa_text)
            if numa_text and int(numa_text) >= 0
            else None
        )

        gpus.append({
            "cuda_index": index,
            "name": row[1].strip(),
            "memory_total_mib": int(
                float(row[2].strip())
            ),
            "pci_bus_id": pci,
            "driver_version": row[4].strip(),
            "numa_node": numa_node,
        })

    return gpus, output


def build_tier_sets(gpu, nodes):
    node_map = {
        n["node_id"]: n for n in nodes
    }

    affinity = gpu["numa_node"]

    if affinity not in node_map:
        return None

    socket = node_map[affinity]["socket_id"]

    if socket is None:
        return None

    return {
        "Local": [affinity],
        "Near": sorted(
            n["node_id"] for n in nodes
            if n["socket_id"] == socket
            and n["node_id"] != affinity
        ),
        "Far": sorted(
            n["node_id"] for n in nodes
            if n["socket_id"] != socket
        ),
    }


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--out", required=True)
    parser.add_argument("--raw-dir", required=True)

    args = parser.parse_args()

    out = pathlib.Path(args.out)
    raw_dir = pathlib.Path(args.raw_dir)

    out.parent.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    commands = {
        "lscpu.txt": ["lscpu"],
        "numactl.txt": ["numactl", "-H"],
        "numastat.txt": ["numastat", "-m"],
        "gpu_topology.txt": ["nvidia-smi", "topo", "-m"],
        "gpu_status.txt": ["nvidia-smi"],
    }

    raw_status = {}

    for filename, command in commands.items():
        rc, output = run_command(command)
        (raw_dir / filename).write_text(
            output, encoding="utf-8"
        )
        raw_status[filename] = rc

    nodes, distances = collect_nodes()
    gpus, gpu_query = collect_gpus()

    issues = []

    if not nodes:
        issues.append("No NUMA memory nodes discovered")

    if not gpus:
        issues.append("No NVIDIA GPU discovered")

    node_ids = {n["node_id"] for n in nodes}

    for node in nodes:
        if node["socket_id"] is None:
            issues.append(
                f"Socket unresolved for node {node['node_id']}"
            )

        row = distances.get(str(node["node_id"]), {})

        if not node_ids.issubset(
            {int(x) for x in row}
        ):
            issues.append(
                f"Incomplete distance row for node "
                f"{node['node_id']}"
            )

    gpu_tiers = {}

    for gpu in gpus:
        affinity = gpu["numa_node"]

        if affinity is None:
            issues.append(
                f"GPU {gpu['cuda_index']} NUMA affinity unresolved"
            )
            continue

        if affinity not in node_ids:
            issues.append(
                f"GPU {gpu['cuda_index']} affinity node missing"
            )
            continue

        tiers = build_tier_sets(gpu, nodes)

        if tiers is None:
            issues.append(
                f"GPU {gpu['cuda_index']} tier map unresolved"
            )
        else:
            gpu_tiers[str(gpu["cuda_index"])] = tiers

    result = {
        "schema_version": 1,
        "captured_at_utc": (
            datetime.datetime.now(
                datetime.timezone.utc
            ).isoformat()
        ),
        "hostname": platform.node(),
        "kernel": platform.release(),
        "architecture": platform.machine(),
        "os_release": read_text("/etc/os-release"),
        "cpu": {
            "lscpu": read_text(raw_dir / "lscpu.txt"),
        },
        "numa": {
            "nodes": nodes,
            "distance_matrix": distances,
        },
        "gpus": gpus,
        "gpu_tier_sets": gpu_tiers,
        "raw_command_status": raw_status,
        "issues": sorted(set(issues)),
        "complete": not issues,
    }

    out.write_text(
        json.dumps(
            result,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    print("PLATFORM_PROBE_FILE=" + str(out))
    print("NUMA_NODE_COUNT=" + str(len(nodes)))
    print("GPU_COUNT=" + str(len(gpus)))

    for gpu in gpus:
        print(
            "GPU{} PCI={} NUMA={}".format(
                gpu["cuda_index"],
                gpu["pci_bus_id"],
                gpu["numa_node"],
            )
        )

        tiers = gpu_tiers.get(
            str(gpu["cuda_index"])
        )

        if tiers:
            for name, members in tiers.items():
                print(
                    f"GPU{gpu['cuda_index']}_{name}={members}"
                )

    for issue in sorted(set(issues)):
        print("PLATFORM_ISSUE=" + issue)

    print(
        "PLATFORM_PROBE="
        + ("PASS" if not issues else "INCOMPLETE")
    )

    return 0 if not issues else 2


if __name__ == "__main__":
    raise SystemExit(main())
