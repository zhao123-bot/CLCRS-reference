#!/usr/bin/env bash

set +e
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

PYTHONPATH="$ROOT/src:$ROOT" \
python3 -m unittest discover \
    -s "$ROOT/tests" \
    -p 'test_online_controller.py' \
    -v

RC=$?

if [ "$RC" -eq 0 ]; then
    echo "ONLINE_CONTROLLER=PASS"
else
    echo "ONLINE_CONTROLLER=FAIL"
fi

exit "$RC"
