#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ ! -f "$ROOT/training/clcrs_adapter.py" ]; then
    echo "ERROR: training/clcrs_adapter.py has not been implemented."
    echo "Connect it to the actual CLCRS core modules first."
    exit 2
fi

if ! python3 -c "import torch" >/dev/null 2>&1; then
    echo "ERROR: PyTorch is required for training."
    echo "Static construction and validation do not require PyTorch."
    exit 3
fi

cd "$ROOT"

PYTHONPATH="$ROOT:$ROOT/src" \
python3 -m training.train \
    --adapter training.clcrs_adapter \
    "$@"
