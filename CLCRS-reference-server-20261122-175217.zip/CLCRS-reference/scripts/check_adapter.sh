#!/usr/bin/env bash

set +e
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "========== CLCRS ADAPTER CHECK =========="

PYTHONPATH="$ROOT:$ROOT/src" \
python3 -m unittest discover \
    -s "$ROOT/tests" \
    -p 'test_adapter_contract.py' \
    -v

RC=$?

if [ "$RC" -eq 0 ]; then
    echo "ADAPTER_INTEGRATION=PASS"
else
    echo "ADAPTER_INTEGRATION=FAIL"
fi

exit "$RC"
