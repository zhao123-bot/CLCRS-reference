#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

for f in \
    configs/platform.yaml \
    configs/ppo.yaml \
    src/clcrs/topology.py \
    src/clcrs/state.py \
    src/clcrs/resolver.py \
    src/clcrs/reward.py \
    src/clcrs/environment.py \
    src/clcrs/policy.py
do
    test -s "$ROOT/$f"
done

python3 -m compileall -q \
    "$ROOT/src/clcrs" \
    "$ROOT/training" \
    "$ROOT/tests"

PYTHONPATH="$ROOT:$ROOT/src" \
python3 -m unittest discover \
    -s "$ROOT/tests" \
    -p 'test_*.py' \
    -v

echo
echo "CORE_FILES=PASS"
echo "PYTHON_SYNTAX=PASS"
echo "REFERENCE_TESTS=PASS"
echo "TORCH_CHECK=DEFERRED_UNTIL_TRAINING"
