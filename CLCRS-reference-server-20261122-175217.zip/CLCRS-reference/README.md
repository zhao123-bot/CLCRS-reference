# CLCRS

Reference implementation of **CLCRS: Latency-Budgeted Reinforcement Learning for GPU-Relative Host-Side NUMA Placement**.

CLCRS studies the initial NUMA placement of host buffers created by explicit GPU offloading. It selects a GPU-relative NUMA tier before first touch and leaves physical-page allocation to the native Linux memory manager.

This repository organizes the main algorithms, interfaces, and construction procedure described in the paper. It is intended as a research reference for adapting CLCRS to different CPU-GPU-NUMA platforms.

## 1. Scope

CLCRS operates between host-buffer creation and physical-page materialization.

The original offloading runtime remains responsible for object lifetime management and subsequent GPU-host data transfers. CLCRS adds:

- GPU-relative NUMA tier classification.
- Runtime state construction.
- PPO-based tier selection.
- Deterministic physical-node resolution.
- Capacity reservation and feasibility checking.
- Latency-budgeted admission and deadline checking.
- NUMA policy setup and native-runtime fallback.

CLCRS runs in user space. It does not modify CUDA/UVM or the Linux kernel, and does not actively migrate physical pages after first touch.

## 2. Placement Model

For a requesting GPU, candidate NUMA nodes are divided into three tiers:

| Tier | Definition |
|---|---|
| Local | NUMA node associated with the requesting GPU |
| Near | Other NUMA nodes in the same CPU socket |
| Far | NUMA nodes in remote CPU sockets |

Tier membership is determined from GPU affinity and CPU-socket topology, rather than fixed physical node IDs.

The PPO policy selects a tier. It does not directly predict a physical NUMA node.

The Tier Resolver performs the physical-node selection using current capacity and node availability.

## 3. Online State

The policy uses an 11-dimensional state:

\[
s_t =
[h_L,h_N,h_F,d_L,d_N,d_F,p_L,p_N,p_F,z_S,z_P]
\]

where:

- \(h_L,h_N,h_F\): normalized effective capacity of the representative node in each tier.
- \(d_L,d_N,d_F\): normalized GPU-relative NUMA distance.
- \(p_L,p_N,p_F\): runtime GPU-NUMA path pressure.
- \(z_S\): normalized host-buffer size.
- \(z_P\): normalized object access priority.

Tier features are derived from one representative candidate node selected using the same deterministic rule as the Tier Resolver. Physical nodes within a tier are not summed or averaged.

For NUMA node \(j\), effective capacity is:

\[
H_j=M_j^{free}-M_j^{guard}-M_j^{inflight}
\]

The representative candidate is selected by maximizing post-allocation capacity headroom:

\[
j_k^\dagger =
\arg\max_{j\in\mathcal{N}_k(g)\cap
\mathcal{N}_{online}\cap\mathcal{N}_{allowed}}
(H_j-S_t^{align})
\]

Ties are resolved by smaller GPU-relative NUMA distance, followed by smaller node ID.

A tier is feasible when its representative node can accommodate the page-aligned request.

The state uses fixed normalization parameters derived from training profiles. These parameters and the feature order are frozen before deployment. Out-of-range observations are clipped.

## 4. GPU-NUMA Path Pressure

For GPU \(g\) and NUMA node \(j\), runtime path pressure is defined as:

\[
p_{g,j}(t)=
\operatorname{clip}
\left(
1-\frac{BW^{obs}_{g,j}(t)}
{BW^{idle}_{g,j}},0,1
\right)
\]

Here, idle bandwidth provides the calibration baseline, while observed bandwidth reflects the current runtime condition.

## 5. Tier Resolution and Resource Management

The Tier Resolver uses the same deterministic selection rule during offline training and online placement.

After a successful placement decision:

1. The selected node's capacity is reserved.
2. The reservation is included in subsequent capacity checks.
3. Page-aligned capacity is accounted for when the object is materialized.
4. Capacity is restored when the object is released.
5. H2D, D2H, and mapped-memory accesses update the corresponding GPU-NUMA path state.

The resulting transition is:

\[
s_{t+1}=\mathcal{T}(s_t,a_t,\xi_t)
\]

where \(\xi_t\) represents external events, including subsequent object arrivals, releases, and background path load.

## 6. Reward Design

For a feasible tier, the immediate reward is:

\[
R_t=R_{base}
-\alpha P_{cap}
-\beta P_{path}
-\gamma_{press}P_{press}
\]

The default parameters are:

| Parameter | Value |
|---|---:|
| \(\alpha\) | 0.45 |
| \(\beta\) | 0.25 |
| \(\gamma_{press}\) | 0.30 |
| \(R_{base}\) | 1.0 |
| \(R_{terminal}\) | -1.0 |
| \(\lambda_{cap}\) | 5.0 |
| \(\epsilon_{press}\) | 0.05 |

An infeasible action violates a hard physical constraint, receives the terminal penalty, and terminates the current training episode.

The reward combines post-placement capacity margin, static GPU-relative path cost, and runtime path pressure. Application execution time is not directly used as the immediate reward.

## 7. PPO Configuration

The paper uses the following PPO configuration:

| Configuration | Value |
|---|---|
| State / action | 11-D / 3 tiers |
| Actor-Critic | 2 × 256 MLP |
| Activation | Tanh |
| Optimizer | Adam |
| Initial learning rate | \(3\times10^{-4}\) |
| Learning-rate schedule | Linear decay |
| Discount factor | 0.99 |
| GAE parameter | 0.95 |
| PPO clipping | 0.20 |
| Rollout length | 2048 |
| Minibatch size | 64 |
| Update epochs | 10 |
| Entropy coefficient | 0.001 |
| Training budget | \(10^6\) steps per seed |
| Random seeds | 5 |

Training episodes use continuous segments of runtime object traces. Object arrivals, overlapping lifetimes, accesses, and releases drive the environment transitions.

Checkpoints are evaluated on independent validation profiles. For each seed, the highest-return checkpoint satisfying the capacity-feasibility requirement is selected. The final deployment policy is selected from the validated candidates.

## 8. Latency-Budgeted Online Control

CLCRS uses a size-dependent admission condition:

\[
\widehat{T}_{ctrl}^{P99}(S)
\leq
\theta T_{ref}^{P99}(S),
\qquad \theta=0.05
\]

For an admitted request, the deadline is:

\[
t_{ddl}=t_0+\theta T_{ref}^{P99}(S)
\]

The control path follows these rules:

- No feasible tier: return to the native runtime.
- One feasible tier: bypass PPO and resolve the node directly.
- Multiple feasible tiers: invoke PPO only after budget admission.
- Deadline expiration: discard the policy result and fall back.
- Lost feasibility, reservation failure, or NUMA-policy setup failure: fall back to the native runtime.

PPO inference is synchronous. The deadline check cannot interrupt an inference pass already in progress, so the mechanism does not provide a hard real-time bound on request waiting time.

## 9. Platform Adaptation

A new platform requires its own calibration.

At minimum, the user should collect:

- GPU PCI locations and NUMA affinity.
- CPU socket and NUMA topology.
- Linux NUMA distance matrix.
- Per-node available and reserved memory capacity.
- GPU-NUMA idle transfer bandwidth.
- Runtime-observed GPU-host transfer bandwidth.
- Object size and allocation-time priority metadata.

A change in NUMA topology, GPU affinity, or memory configuration requires recalibration. Persistent observations outside the training-profile coverage also require recalibration.

## 10. Construction Workflow

The intended workflow is:

1. Collect platform topology and capacity information.
2. Measure GPU-NUMA transfer paths.
3. Construct the Local/Near/Far tier map.
4. Build the 11-dimensional state.
5. Prepare continuous object-request traces.
6. Construct the calibrated transition environment.
7. Configure the reward and physical feasibility constraints.
8. Train PPO using the paper's configuration.
9. Evaluate checkpoints on independent validation profiles.
10. Freeze the selected policy and normalization parameters.
11. Integrate the inference and placement interfaces into the host-buffer creation path.

The training and validation procedures are provided as reference construction steps. Users must supply platform measurements and their own permitted workload traces.

## 11. Repository Contents

This repository focuses on the algorithms and interfaces required to understand and construct CLCRS.

It does not distribute:

- Trained PPO model weights.
- Private runtime traces.
- Full experimental logs.
- Private server configurations.
- Unpublished follow-up research code.

The repository is not a turnkey reproduction package for the reported experimental results. Hardware-specific runtime integration and calibration are required.

## 12. Implementation Status

The source files are being organized incrementally against the paper's method and implementation boundaries.

A reference interface should not be interpreted as a verified production integration. Platform-dependent operations must be connected to the target offloading runtime and tested on the corresponding system before deployment.

