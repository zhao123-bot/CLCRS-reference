import unittest

from clcrs.controller import (
    CLCRSController,
    RuntimePlacementRequest,
)
from clcrs.latency_budget import (
    LatencyBucket,
    LatencyBudget,
)
from clcrs.resolver import TierResolver
from clcrs.state import (
    NodeRuntimeState,
    PlacementRequest,
    RuntimeSnapshot,
    SizeNormalizer,
    StateBuilder,
)
from clcrs.topology import (
    GPUTopology,
    NodeTopology,
    Tier,
    build_tier_map,
)


class FakePolicy:

    def __init__(self, tier=Tier.NEAR, callback=None):
        self.tier = tier
        self.callback = callback
        self.calls = 0

    def predict(self, state):
        self.calls += 1

        if self.callback:
            self.callback()

        return self.tier


class FakeExecutor:

    def __init__(self, success=True):
        self.success = success
        self.calls = 0
        self.last = None

    def apply_policy(self, address, size_bytes, node_id):
        self.calls += 1
        self.last = (address, size_bytes, node_id)
        return self.success


class FakeNative:

    def __init__(self):
        self.calls = []

    def fallback(self, request, reason):
        self.calls.append(reason)
        return "NATIVE"


class SequenceClock:

    def __init__(self, values):
        self.values = list(values)
        self.last = 0

    def __call__(self):
        if self.values:
            self.last = self.values.pop(0)
        return self.last


class OnlineControllerTest(unittest.TestCase):

    def setUp(self):

        self.gpu = GPUTopology(
            cuda_index=0,
            numa_node=0,
            pci_bus_id="TEST",
        )

        self.nodes = [
            NodeTopology(0, 0, 1000000),
            NodeTopology(1, 0, 1000000),
            NodeTopology(2, 1, 1000000),
        ]

        self.tier_map = build_tier_map(
            self.gpu,
            self.nodes,
            {
                0: {
                    0: 10,
                    1: 20,
                    2: 40,
                }
            },
        )

        self.snapshot = RuntimeSnapshot(
            node_states={
                i: NodeRuntimeState(
                    node_id=i,
                    free_bytes=100000,
                    guard_bytes=0,
                    inflight_bytes=0,
                    online=True,
                    allowed=True,
                )
                for i in (0, 1, 2)
            },
            path_pressure={
                (0, 0): 0.0,
                (0, 1): 0.0,
                (0, 2): 0.0,
            },
        )

        self.request = PlacementRequest(
            object_id="buffer-A",
            requested_size_bytes=4096,
            aligned_size_bytes=4096,
            gpu_index=0,
            priority_level=1,
        )

        self.runtime_request = RuntimePlacementRequest(
            address=0x100000,
            placement=self.request,
        )

        self.state_builder = StateBuilder(
            SizeNormalizer(
                lambda size: min(1.0, size / 8192.0)
            )
        )

        self.budget = LatencyBudget(
            control_buckets=[
                LatencyBucket(8192, 1000000),
            ],
            native_buckets=[
                LatencyBucket(8192, 100000000),
            ],
            theta=0.05,
        )

    def make_controller(
        self,
        policy=None,
        executor=None,
        clock=None,
        budget=None,
    ):
        self.policy = policy or FakePolicy()
        self.executor = executor or FakeExecutor()
        self.native = FakeNative()

        return CLCRSController(
            state_builder=self.state_builder,
            policy=self.policy,
            latency_budget=budget or self.budget,
            executor=self.executor,
            native_runtime=self.native,
            resolver=TierResolver(),
            clock_ns=clock or (lambda: 0),
        )

    def test_multiple_tiers_use_frozen_policy(self):

        controller = self.make_controller()

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "placed")
        self.assertEqual(result.path, "frozen_ppo")
        self.assertEqual(result.tier, "Near")
        self.assertEqual(result.node_id, 1)
        self.assertEqual(self.policy.calls, 1)
        self.assertEqual(self.executor.calls, 1)
        self.assertEqual(
            self.snapshot.node_states[1].inflight_bytes,
            4096,
        )

    def test_single_feasible_tier_bypasses_ppo(self):

        self.snapshot.node_states[1].free_bytes = 1024
        self.snapshot.node_states[2].free_bytes = 1024

        controller = self.make_controller()

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "placed")
        self.assertEqual(
            result.path,
            "single_tier_bypass",
        )
        self.assertEqual(result.tier, "Local")
        self.assertEqual(self.policy.calls, 0)

    def test_no_feasible_tier_falls_back(self):

        for state in self.snapshot.node_states.values():
            state.free_bytes = 1024

        controller = self.make_controller()

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "fallback")
        self.assertEqual(result.reason, "no_feasible_tier")
        self.assertEqual(self.policy.calls, 0)
        self.assertEqual(self.executor.calls, 0)

    def test_budget_failure_bypasses_policy(self):

        bad_budget = LatencyBudget(
            control_buckets=[
                LatencyBucket(8192, 6000000),
            ],
            native_buckets=[
                LatencyBucket(8192, 100000000),
            ],
            theta=0.05,
        )

        controller = self.make_controller(
            budget=bad_budget
        )

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "fallback")
        self.assertEqual(
            result.reason,
            "budget_control_p99_exceeds_budget",
        )
        self.assertEqual(self.policy.calls, 0)

    def test_policy_result_revalidated_after_state_change(self):

        def mutate():
            self.snapshot.node_states[1].free_bytes = 0
            self.snapshot.version += 1

        policy = FakePolicy(
            tier=Tier.NEAR,
            callback=mutate,
        )

        controller = self.make_controller(
            policy=policy
        )

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "fallback")
        self.assertEqual(
            result.reason,
            "selected_tier_lost_feasibility",
        )
        self.assertEqual(self.executor.calls, 0)

    def test_executor_failure_releases_reservation(self):

        controller = self.make_controller(
            executor=FakeExecutor(success=False)
        )

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "fallback")
        self.assertEqual(
            result.reason,
            "numa_policy_setup_failed",
        )

        self.assertEqual(
            self.snapshot.node_states[1].inflight_bytes,
            0,
        )

        self.assertEqual(
            controller.pending_reservations,
            0,
        )

    def test_deadline_after_state_construction(self):

        controller = self.make_controller(
            clock=SequenceClock([
                0,
                5000000,
            ])
        )

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        self.assertEqual(result.status, "fallback")
        self.assertEqual(
            result.reason,
            "deadline_after_state",
        )

        self.assertEqual(self.policy.calls, 0)

    def test_materialization_commits_reservation(self):

        controller = self.make_controller()

        result = controller.place(
            self.runtime_request,
            self.snapshot,
            self.tier_map,
        )

        token = result.reservation_token

        self.assertIsNotNone(token)
        self.assertEqual(controller.pending_reservations, 1)

        self.assertTrue(
            controller.notify_materialized(
                token,
                observed_free_bytes=100000 - 4096,
            )
        )

        self.assertEqual(
            self.snapshot.node_states[1].free_bytes,
            95904,
        )

        self.assertEqual(
            self.snapshot.node_states[1].inflight_bytes,
            0,
        )

        self.assertEqual(controller.pending_reservations, 0)


if __name__ == "__main__":
    unittest.main()
