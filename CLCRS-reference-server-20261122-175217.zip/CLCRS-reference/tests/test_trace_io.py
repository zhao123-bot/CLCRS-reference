import json
import tempfile
import unittest
from pathlib import Path

from training.trace_io import load_jsonl


class TraceIOTest(unittest.TestCase):

    def write_trace(self, records):
        handle = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", delete=False
        )

        for record in records:
            handle.write(json.dumps(record) + "\n")

        handle.close()
        return Path(handle.name)

    def test_valid_lifecycle(self):
        path = self.write_trace([
            {
                "timestamp_ns": 1,
                "event": "create",
                "object_id": "a",
                "gpu_id": 0,
                "size_bytes": 4096,
                "priority": 2
            },
            {
                "timestamp_ns": 2,
                "event": "access",
                "object_id": "a",
                "direction": "H2D",
                "bytes": 1024
            },
            {
                "timestamp_ns": 3,
                "event": "release",
                "object_id": "a"
            }
        ])

        try:
            events = load_jsonl(path)
            self.assertEqual(len(events), 3)
            self.assertEqual(events[0].event, "create")
            self.assertEqual(events[1].direction, "H2D")
            self.assertEqual(events[2].event, "release")
        finally:
            path.unlink()

    def test_invalid_priority(self):
        path = self.write_trace([{
            "timestamp_ns": 1,
            "event": "create",
            "object_id": "a",
            "gpu_id": 0,
            "size_bytes": 4096,
            "priority": 5
        }])

        try:
            with self.assertRaises(ValueError):
                load_jsonl(path)
        finally:
            path.unlink()

    def test_non_chronological_trace(self):
        path = self.write_trace([
            {
                "timestamp_ns": 10,
                "event": "release",
                "object_id": "a"
            },
            {
                "timestamp_ns": 5,
                "event": "release",
                "object_id": "b"
            }
        ])

        try:
            with self.assertRaises(ValueError):
                load_jsonl(path)
        finally:
            path.unlink()


if __name__ == "__main__":
    unittest.main()
