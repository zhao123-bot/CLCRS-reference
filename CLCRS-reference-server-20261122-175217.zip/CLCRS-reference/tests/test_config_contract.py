import unittest
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None


@unittest.skipIf(yaml is None, "PyYAML is not installed")
class ConfigContractTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        root = Path(__file__).resolve().parents[1]

        with (root / "configs/ppo.yaml").open(
            encoding="utf-8"
        ) as f:
            cls.ppo = yaml.safe_load(f)

        with (root / "configs/platform.yaml").open(
            encoding="utf-8"
        ) as f:
            cls.platform = yaml.safe_load(f)

    def test_state_and_actions(self):
        policy = self.ppo["policy"]

        self.assertEqual(policy["state"]["dimension"], 11)
        self.assertEqual(
            policy["action"]["tiers"], ["Local", "Near", "Far"]
        )

    def test_network(self):
        network = self.ppo["policy"]["network"]

        self.assertEqual(network["actor"]["hidden_sizes"], [256, 256])
        self.assertEqual(network["critic"]["hidden_sizes"], [256, 256])
        self.assertEqual(network["actor"]["activation"], "Tanh")

    def test_training_budget(self):
        training = self.ppo["training"]

        self.assertEqual(training["steps_per_seed"], 1000000)
        self.assertEqual(training["random_seed_count"], 5)
        self.assertFalse(training["early_stopping"])

    def test_ppo_parameters(self):
        ppo = self.ppo["policy"]["ppo"]

        self.assertEqual(ppo["discount_factor"], 0.99)
        self.assertEqual(ppo["gae_lambda"], 0.95)
        self.assertEqual(ppo["clip_parameter"], 0.20)
        self.assertEqual(ppo["rollout_length"], 2048)
        self.assertEqual(ppo["minibatch_size"], 64)
        self.assertEqual(ppo["update_epochs"], 10)

    def test_reward_boundary(self):
        reward = self.ppo["reward"]

        self.assertEqual(reward["weights"]["alpha"], 0.45)
        self.assertEqual(reward["weights"]["beta"], 0.25)
        self.assertEqual(reward["weights"]["gamma_press"], 0.30)

        self.assertNotIn(
            "adjusted_by", reward["static_path_penalty"]
        )

        self.assertFalse(
            reward["application_end_to_end_time"][
                "used_as_immediate_reward"
            ]
        )

    def test_no_active_page_migration(self):
        placement = self.platform["runtime"]["placement"]
        self.assertFalse(placement["migrate_existing_pages"])


if __name__ == "__main__":
    unittest.main()
