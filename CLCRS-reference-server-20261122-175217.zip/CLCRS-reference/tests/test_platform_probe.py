import pathlib
import sys
import unittest

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1] / "scripts"),
)

from collect_platform_probe import (
    parse_cpulist,
    parse_distance,
    parse_node_meminfo,
    normalize_pci,
)


class PlatformProbeTest(unittest.TestCase):

    def test_cpu_list(self):
        self.assertEqual(
            parse_cpulist("0-3,8,10-11"),
            [0, 1, 2, 3, 8, 10, 11],
        )

    def test_distance(self):
        self.assertEqual(
            parse_distance(
                "10 16 22 28",
                [0, 1, 2, 3],
            ),
            {
                "0": 10,
                "1": 16,
                "2": 22,
                "3": 28,
            },
        )

    def test_meminfo(self):
        sample = (
            "Node 2 MemTotal: 65536 kB\n"
            "Node 2 MemFree: 32768 kB\n"
        )

        result = parse_node_meminfo(sample, 2)

        self.assertEqual(
            result["memtotal_bytes"],
            65536 * 1024,
        )

        self.assertEqual(
            result["memfree_bytes"],
            32768 * 1024,
        )

    def test_pci_normalization(self):
        self.assertEqual(
            normalize_pci("00000000:65:00.0"),
            "0000:65:00.0",
        )


if __name__ == "__main__":
    unittest.main()
