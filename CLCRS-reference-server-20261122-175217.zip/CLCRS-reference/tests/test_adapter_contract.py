import json
import tempfile
import unittest
from pathlib import Path

from training.clcrs_adapter import (
    build_environment,
    fit_normalization,
)


class AdapterContractTest(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

        self.trace = self.root / "trace.jsonl"
        self.manifest_path = self.root / "profile.json"

        events = [
            {
                "timestamp_ns": 0,
                "event": "create",
                "object_id": "object-A",
                "gpu_id": 0,
                "size_bytes": 4096,
                "priority": 1,
            },
            {
                "timestamp_ns": 1000000000,
                "event": "access",
                "object_id": "object-A",
                "direction": "H2D",
                "transferred_bytes": 100,
            },
            {
                "timestamp_ns": 2000000000,
                "event": "release",
                "object_id": "object-A",
            },
            {
                "timestamp_ns": 3000000000,
                "event": "create",
                "object_id": "object-B",
                "gpu_id": 0,
                "size_bytes": 8192,
                "priority": 2,
            },
            {
                "timestamp_ns": 4000000000,
                "event": "release",
                "object_id": "object-B",
            },
        ]

        with self.trace.open("w", encoding="utf-8") as stream:
            for event in events:
                stream.write(json.dumps(event) + "\n")

        nodes = [
            {
                "node_id": 0,
                "socket_id": 0,
                "total_memory_bytes": 2000000,
            },
            {
                "node_id": 1,
                "socket_id": 0,
                "total_memory_bytes": 2000000,
            },
            {
                "node_id": 2,
                "socket_id": 1,
                "total_memory_bytes": 2000000,
            },
        ]

        runtime_nodes = [
            {
                "node_id": node_id,
                "free_bytes": 1000000,
                "guard_bytes": 100000,
                "inflight_bytes": 0,
                "online": True,
                "allowed": True,
            }
            for node_id in (0, 1, 2)
        ]

        path_calibration = [
            {
                "gpu_index": 0,
                "node_id": node_id,
                "idle_bandwidth_bytes_per_sec": 1000,
            }
            for node_id in (0, 1, 2)
        ]

        manifest = {
            "schema_version": 1,
            "profile_id": "unit-test-profile",
            "split": "train",
            "trace_file": str(self.trace),
            "allocation_alignment_bytes": 4096,
            "topology": {
                "gpu": {
                    "cuda_index": 0,
                    "numa_node": 0,
                    "pci_bus_id": "TEST",
                },
                "nodes": nodes,
                "distance_matrix": {
                    "0": {
                        "0": 10,
                        "1": 20,
                        "2": 40,
                    }
                },
            },
            "runtime": {
                "nodes": runtime_nodes,
                "path_calibration": path_calibration,
                "path_pressure_source": (
                    "trace_derived_throughput"
                ),
            },
            "calibration": {
                "pressure_samples": [
                    0.0,
                    0.25,
                    0.5,
                    0.75,
                ]
            },
        }

        self.manifest_path.write_text(
            json.dumps(manifest, indent=2),
            encoding="utf-8",
        )

        self.normalization = fit_normalization(
            [self.manifest_path]
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_training_normalization(self):

        self.assertEqual(
            self.normalization["source"],
            "training_profiles",
        )

        self.assertEqual(
            self.normalization["size_max_bytes"],
            8192,
        )

        self.assertLess(
            self.normalization["pressure_lower"],
            self.normalization["pressure_upper"],
        )

    def test_full_lifecycle_and_state(self):

        env = build_environment(
            self.manifest_path,
            split="train",
            normalization=self.normalization,
        )

        observation = env.reset()

        self.assertEqual(len(observation), 11)

        # First object: Local placement.
        next_state, reward, done, info = env.step(0)

        self.assertFalse(done)
        self.assertTrue(info["capacity_feasible"])
        self.assertFalse(info["infeasible_action"])
        self.assertEqual(len(next_state), 11)

        # 100 bytes / 1 second versus 1000 B/s idle baseline:
        # pressure = 1 - 100/1000 = 0.9.
        pressure = env.base.snapshot.path_pressure[
            (0, 0)
        ]

        self.assertAlmostEqual(
            pressure,
            0.9,
            places=6,
        )

        self.assertAlmostEqual(
            next_state[6],
            0.9,
            places=6,
        )

        # Object A was released before object B.
        self.assertEqual(
            env.base.snapshot.node_states[0].free_bytes,
            1000000,
        )

        # Second object: Near placement.
        final_state, reward, done, info = env.step(1)

        self.assertTrue(done)
        self.assertIsNone(final_state)
        self.assertTrue(info["capacity_feasible"])

        # Object B was also released.
        self.assertEqual(
            env.base.snapshot.node_states[1].free_bytes,
            1000000,
        )

    def test_trace_profile_split(self):

        with self.assertRaises(ValueError):
            build_environment(
                self.manifest_path,
                split="validation",
                normalization=self.normalization,
            )


if __name__ == "__main__":
    unittest.main()
